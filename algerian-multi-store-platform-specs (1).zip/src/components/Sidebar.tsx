import { useStore } from '../contexts/StoreContext';
import {
  LayoutDashboard, ShoppingBag, Package, ClipboardList, Truck,
  Settings, Palette, BarChart3, Link, Store, ChevronDown, Plus, LogOut, X
} from 'lucide-react';
import { useState } from 'react';

interface Props {
  onLogout: () => void;
}

export default function Sidebar({ onLogout }: Props) {
  const { state, dispatch, currentStore } = useStore();
  const [storeDropdown, setStoreDropdown] = useState(false);

  const menuItems = [
    { id: 'dashboard', icon: <LayoutDashboard className="w-5 h-5" />, label: 'لوحة التحكم' },
    { id: 'products', icon: <Package className="w-5 h-5" />, label: 'المنتجات' },
    { id: 'orders', icon: <ClipboardList className="w-5 h-5" />, label: 'الطلبات' },
    { id: 'delivery', icon: <Truck className="w-5 h-5" />, label: 'التوصيل والولايات' },
    { id: 'design', icon: <Palette className="w-5 h-5" />, label: 'التصميم والتخصيص' },
    { id: 'analytics', icon: <BarChart3 className="w-5 h-5" />, label: 'Google Analytics' },
    { id: 'integration', icon: <Link className="w-5 h-5" />, label: 'الربط والمزامنة' },
    { id: 'settings', icon: <Settings className="w-5 h-5" />, label: 'الإعدادات' },
    { id: 'preview', icon: <Store className="w-5 h-5" />, label: 'معاينة المتجر' },
  ];

  return (
    <>
      {/* Mobile overlay */}
      {state.sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
        />
      )}
      
      <aside className={`fixed top-0 right-0 h-full bg-white border-l border-gray-200 z-50 transition-all duration-300 flex flex-col ${
        state.sidebarOpen ? 'w-72 translate-x-0' : 'w-72 translate-x-full lg:translate-x-0 lg:w-20'
      }`}>
        {/* Header */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className={`flex items-center gap-3 ${!state.sidebarOpen ? 'lg:justify-center' : ''}`}>
              <div className="w-10 h-10 gradient-bg rounded-xl flex items-center justify-center flex-shrink-0">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              {state.sidebarOpen && <span className="font-bold text-gray-900 text-lg">DZ Store</span>}
            </div>
            <button
              onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
              className="lg:hidden p-1 rounded-lg hover:bg-gray-100"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>

        {/* Store Selector */}
        {state.sidebarOpen && (
          <div className="p-4 border-b border-gray-100">
            <div className="relative">
              <button
                onClick={() => setStoreDropdown(!storeDropdown)}
                className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold" style={{ background: currentStore?.primaryColor || '#6366f1' }}>
                    {currentStore?.name?.[0] || '?'}
                  </div>
                  <span className="text-sm font-medium text-gray-700 truncate max-w-[140px]">
                    {currentStore?.name || 'اختر متجر'}
                  </span>
                </div>
                <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${storeDropdown ? 'rotate-180' : ''}`} />
              </button>

              {storeDropdown && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 z-50 py-2 max-h-60 overflow-y-auto">
                  {state.stores.map(store => (
                    <button
                      key={store.id}
                      onClick={() => {
                        dispatch({ type: 'SET_CURRENT_STORE', payload: store.id });
                        setStoreDropdown(false);
                      }}
                      className={`w-full flex items-center gap-2 px-4 py-2.5 hover:bg-gray-50 transition-colors ${
                        store.id === state.currentStoreId ? 'bg-indigo-50' : ''
                      }`}
                    >
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold" style={{ background: store.primaryColor }}>
                        {store.name[0]}
                      </div>
                      <span className="text-sm text-gray-700">{store.name}</span>
                    </button>
                  ))}
                  <button
                    onClick={() => {
                      dispatch({ type: 'SET_VIEW', payload: 'create-store' });
                      setStoreDropdown(false);
                    }}
                    className="w-full flex items-center gap-2 px-4 py-2.5 hover:bg-gray-50 text-indigo-600 border-t border-gray-100 mt-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span className="text-sm font-medium">إنشاء متجر جديد</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Menu */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => {
                dispatch({ type: 'SET_VIEW', payload: item.id });
                if (window.innerWidth < 1024) dispatch({ type: 'TOGGLE_SIDEBAR' });
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl mb-1 transition-all ${
                state.currentView === item.id
                  ? 'bg-indigo-50 text-indigo-600 font-medium'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              } ${!state.sidebarOpen ? 'lg:justify-center lg:px-2' : ''}`}
              title={!state.sidebarOpen ? item.label : undefined}
            >
              {item.icon}
              {state.sidebarOpen && <span className="text-sm">{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-gray-100">
          <button
            onClick={onLogout}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-gray-500 hover:bg-red-50 hover:text-red-600 transition-colors ${
              !state.sidebarOpen ? 'lg:justify-center' : ''
            }`}
          >
            <LogOut className="w-5 h-5" />
            {state.sidebarOpen && <span className="text-sm">خروج</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
