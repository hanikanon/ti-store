import { useStore } from '../contexts/StoreContext';
import { BarChart3, ExternalLink, Save, AlertCircle, CheckCircle } from 'lucide-react';
import { useState } from 'react';

export default function AnalyticsView() {
  const { dispatch, currentStore } = useStore();
  const [trackingId, setTrackingId] = useState(currentStore?.googleAnalyticsId || '');
  const [saved, setSaved] = useState(false);

  if (!currentStore) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const handleSave = () => {
    dispatch({
      type: 'UPDATE_STORE',
      payload: { ...currentStore, googleAnalyticsId: trackingId },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="animate-fade-in max-w-2xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Google Analytics</h1>
        <p className="text-gray-500 mt-1">ربط متجرك بـ Google Analytics لتتبع الزوار والمبيعات</p>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-orange-500" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">ربط Google Analytics</h3>
            <p className="text-sm text-gray-500">أدخل معرف التتبع الخاص بمتجرك</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Tracking ID / Measurement ID</label>
            <input
              type="text"
              value={trackingId}
              onChange={e => { setTrackingId(e.target.value); setSaved(false); }}
              placeholder="G-XXXXXXXXXX أو UA-XXXXXXXXX-X"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              dir="ltr"
            />
            <p className="text-xs text-gray-400 mt-2">
              يمكنك الحصول على معرف التتبع من{' '}
              <a href="https://analytics.google.com" target="_blank" rel="noopener noreferrer" className="text-indigo-500 hover:underline inline-flex items-center gap-1">
                Google Analytics
                <ExternalLink className="w-3 h-3" />
              </a>
            </p>
          </div>

          <button
            onClick={handleSave}
            className="flex items-center gap-2 gradient-bg text-white px-6 py-2.5 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
          >
            {saved ? <CheckCircle className="w-4 h-4" /> : <Save className="w-4 h-4" />}
            {saved ? 'تم الحفظ ✓' : 'حفظ'}
          </button>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-semibold text-blue-800 text-sm">كيفية الربط</p>
            <ol className="text-sm text-blue-700 mt-2 space-y-1.5 list-decimal list-inside">
              <li>اذهب إلى Google Analytics وأنشئ حسابًا إذا لم يكن لديك واحد</li>
              <li>أنشئ موقع (Property) جديد باسم متجرك</li>
              <li>انسخ معرف التتبع (Measurement ID) مثل G-XXXXXXXXXX</li>
              <li>الصقه في الحقل أعلاه واضغط حفظ</li>
              <li>سيتم إضافة كود التتبع تلقائياً في متجرك</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
