import { Store, ShoppingCart, Truck, BarChart3, Layers, Globe, Zap, Shield, ArrowLeft, CheckCircle2, Sparkles } from 'lucide-react';

interface Props {
  onEnterDashboard: () => void;
}

export default function LandingPage({ onEnterDashboard }: Props) {
  const features = [
    { icon: <Layers className="w-7 h-7" />, title: 'تعدد المتاجر', desc: 'أنشئ وأدر عدة متاجر مستقلة من لوحة تحكم واحدة' },
    { icon: <ShoppingCart className="w-7 h-7" />, title: 'نظام طلبات متقدم', desc: 'معالجة حتى 500 طلب/ثانية مع نظام Queue ذكي' },
    { icon: <Truck className="w-7 h-7" />, title: '58 ولاية جزائرية', desc: 'دعم كامل لجميع الولايات والبلديات مع أسعار توصيل مخصصة' },
    { icon: <BarChart3 className="w-7 h-7" />, title: 'Google Analytics', desc: 'ربط مباشر مع Google Analytics لتتبع الأداء' },
    { icon: <Globe className="w-7 h-7" />, title: 'مزامنة فورية', desc: 'مزامنة ثنائية مع Google Sheets في الوقت الحقيقي' },
    { icon: <Zap className="w-7 h-7" />, title: 'أداء خارق', desc: 'بنية تحتية سحابية قابلة للتوسع بدون حدود' },
    { icon: <Shield className="w-7 h-7" />, title: 'أمان متقدم', desc: 'حماية كاملة للبيانات مع تشفير متطور' },
    { icon: <Store className="w-7 h-7" />, title: 'تخصيص كامل', desc: 'صمم متجرك بالكامل بدون سطر كود واحد' },
  ];

  return (
    <div className="min-h-screen bg-white overflow-hidden">
      {/* Hero */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-bg opacity-95"></div>
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-72 h-72 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-20 w-96 h-96 bg-purple-300/20 rounded-full blur-3xl"></div>
          <div className="absolute top-40 left-1/3 w-64 h-64 bg-indigo-300/15 rounded-full blur-3xl"></div>
        </div>
        
        <nav className="relative z-10 flex items-center justify-between px-8 py-5 max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <Store className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">DZ Store</span>
          </div>
          <button
            onClick={onEnterDashboard}
            className="flex items-center gap-2 bg-white text-indigo-600 px-6 py-2.5 rounded-xl font-semibold hover:bg-indigo-50 transition-all shadow-lg hover:shadow-xl"
          >
            دخول لوحة التحكم
            <ArrowLeft className="w-4 h-4" />
          </button>
        </nav>

        <div className="relative z-10 max-w-7xl mx-auto px-8 pt-16 pb-28 text-center">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm text-white px-5 py-2 rounded-full text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4" />
            منصة المتاجر الجزائرية الأولى بتقنية السحابة
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-white mb-6 leading-tight">
            أنشئ متجرك الإلكتروني
            <br />
            <span className="text-yellow-300">في دقائق</span>
          </h1>
          <p className="text-xl text-indigo-100 max-w-2xl mx-auto mb-10 leading-relaxed">
            منصة متكاملة لإنشاء وإدارة المتاجر الإلكترونية في الجزائر.
            دعم كامل لـ 58 ولاية مع نظام طلبات فائق السرعة ومزامنة فورية.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onEnterDashboard}
              className="flex items-center gap-3 bg-white text-indigo-600 px-10 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-50 transition-all shadow-2xl hover:shadow-3xl transform hover:scale-105"
            >
              ابدأ الآن مجاناً
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-indigo-200">
              <CheckCircle2 className="w-5 h-5" />
              <span>بدون بطاقة ائتمان</span>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-5xl mx-auto -mt-16 relative z-20 px-8">
        <div className="bg-white rounded-2xl shadow-2xl p-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: '58', label: 'ولاية مدعومة' },
            { value: '+500', label: 'طلب/ثانية' },
            { value: '∞', label: 'متاجر' },
            { value: '24/7', label: 'دعم فني' },
          ].map((s, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl font-black text-indigo-600">{s.value}</div>
              <div className="text-gray-500 text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-black text-gray-900 mb-4">كل ما تحتاجه في منصة واحدة</h2>
          <p className="text-gray-500 text-lg max-w-xl mx-auto">أدوات متقدمة لإدارة متجرك بكفاءة عالية وأداء استثنائي</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <div key={i} className="group bg-white rounded-2xl p-6 border border-gray-100 hover:border-indigo-200 hover:shadow-xl transition-all duration-300 cursor-default">
              <div className="w-14 h-14 bg-indigo-50 group-hover:bg-indigo-100 rounded-2xl flex items-center justify-center text-indigo-600 mb-4 transition-colors">
                {f.icon}
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{f.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-gray-50 py-24">
        <div className="max-w-7xl mx-auto px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black text-gray-900 mb-4">كيف يعمل النظام؟</h2>
            <p className="text-gray-500 text-lg">ثلاث خطوات بسيطة لإطلاق متجرك</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'أنشئ متجرك', desc: 'اختر اسم متجرك وخصص التصميم والألوان بالكامل حسب رغبتك' },
              { step: '02', title: 'أضف المنتجات', desc: 'أضف منتجاتك مع الصور والأسعار والمخزون وحدد أسعار التوصيل' },
              { step: '03', title: 'ابدأ البيع', desc: 'شارك رابط متجرك واستقبل الطلبات فوراً مع مزامنة Google Sheets' },
            ].map((s, i) => (
              <div key={i} className="relative bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                <div className="text-6xl font-black text-indigo-100 absolute top-4 left-4">{s.step}</div>
                <div className="relative">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 mt-8">{s.title}</h3>
                  <p className="text-gray-500 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-8 text-center">
          <div className="gradient-bg rounded-3xl p-12 md:p-16 text-white relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full">
              <div className="absolute top-10 right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
              <div className="absolute bottom-10 left-10 w-56 h-56 bg-purple-300/10 rounded-full blur-2xl"></div>
            </div>
            <div className="relative">
              <h2 className="text-4xl font-black mb-4">جاهز لإطلاق متجرك؟</h2>
              <p className="text-indigo-100 text-lg mb-8 max-w-lg mx-auto">
                انضم لمئات التجار الجزائريين الذين يستخدمون DZ Store لتنمية أعمالهم
              </p>
              <button
                onClick={onEnterDashboard}
                className="inline-flex items-center gap-3 bg-white text-indigo-600 px-10 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-50 transition-all shadow-2xl transform hover:scale-105"
              >
                ابدأ الآن
                <ArrowLeft className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-100 py-8">
        <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-indigo-600" />
            <span className="font-bold text-gray-900">DZ Store</span>
          </div>
          <p className="text-gray-400 text-sm">© 2026 DZ Store - منصة المتاجر الجزائرية. جميع الحقوق محفوظة.</p>
        </div>
      </footer>
    </div>
  );
}
