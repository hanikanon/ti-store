import { useStore } from '../contexts/StoreContext';
import { Database, Cloud, Save, CheckCircle, AlertTriangle, RefreshCw, Code, ExternalLink } from 'lucide-react';
import { useState } from 'react';

export default function IntegrationView() {
  const { dispatch, currentStore } = useStore();
  const [sheetId, setSheetId] = useState(currentStore?.googleSheetId || '');
  const [scriptUrl, setScriptUrl] = useState(currentStore?.googleAppsScriptUrl || '');
  const [saved, setSaved] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);

  if (!currentStore) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const handleSave = () => {
    dispatch({
      type: 'UPDATE_STORE',
      payload: { ...currentStore, googleSheetId: sheetId, googleAppsScriptUrl: scriptUrl },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const testConnection = async () => {
    if (!scriptUrl) {
      setTestResult('error');
      return;
    }
    try {
      await fetch(scriptUrl, { method: 'GET', mode: 'no-cors' });
      setTestResult('success');
    } catch {
      setTestResult('error');
    }
    setTimeout(() => setTestResult(null), 5000);
  };

  return (
    <div className="animate-fade-in max-w-3xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">الربط والمزامنة</h1>
        <p className="text-gray-500 mt-1">ربط متجرك مع Google Apps Script وGoogle Sheets</p>
      </div>

      {/* Architecture Diagram */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 mb-6 border border-indigo-100">
        <h3 className="font-bold text-gray-900 mb-4">كيف يعمل النظام؟</h3>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <div className="bg-white rounded-xl p-3 text-center shadow-sm">
            <span className="text-2xl mb-1 block">🛒</span>
            <span className="text-xs font-medium text-gray-700">المتجر</span>
          </div>
          <span className="text-indigo-400 font-bold">→</span>
          <div className="bg-white rounded-xl p-3 text-center shadow-sm">
            <span className="text-2xl mb-1 block">⚡</span>
            <span className="text-xs font-medium text-gray-700">Queue System</span>
          </div>
          <span className="text-indigo-400 font-bold">→</span>
          <div className="bg-white rounded-xl p-3 text-center shadow-sm">
            <span className="text-2xl mb-1 block">☁️</span>
            <span className="text-xs font-medium text-gray-700">Google Apps Script</span>
          </div>
          <span className="text-indigo-400 font-bold">⇄</span>
          <div className="bg-white rounded-xl p-3 text-center shadow-sm">
            <span className="text-2xl mb-1 block">📊</span>
            <span className="text-xs font-medium text-gray-700">Google Sheets</span>
          </div>
        </div>
        <p className="text-center text-xs text-indigo-600 mt-3">مزامنة ثنائية فورية - المتجر ↔ Google Sheets</p>
      </div>

      {/* Google Sheet */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center">
            <Database className="w-6 h-6 text-emerald-500" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Google Sheet</h3>
            <p className="text-sm text-gray-500">قاعدة بيانات المتجر</p>
          </div>
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Google Sheet ID</label>
          <input
            type="text"
            value={sheetId}
            onChange={e => { setSheetId(e.target.value); setSaved(false); }}
            placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms"
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
            dir="ltr"
          />
          <p className="text-xs text-gray-400 mt-2">
            الرابط: https://docs.google.com/spreadsheets/d/<span className="text-indigo-500 font-mono">SHEET_ID</span>/edit
          </p>
        </div>
      </div>

      {/* Google Apps Script */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
            <Cloud className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Google Apps Script</h3>
            <p className="text-sm text-gray-500">طبقة الـ Backend لمعالجة الطلبات</p>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">رابط Web App URL</label>
            <input
              type="text"
              value={scriptUrl}
              onChange={e => { setScriptUrl(e.target.value); setSaved(false); }}
              placeholder="https://script.google.com/macros/s/AKfycb.../exec"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              dir="ltr"
            />
          </div>
          <div className="flex gap-3">
            <button
              onClick={testConnection}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-50 text-blue-600 rounded-xl text-sm font-medium hover:bg-blue-100 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              اختبار الاتصال
            </button>
            {testResult === 'success' && (
              <span className="flex items-center gap-1.5 text-emerald-600 text-sm">
                <CheckCircle className="w-4 h-4" /> تم الاتصال بنجاح
              </span>
            )}
            {testResult === 'error' && (
              <span className="flex items-center gap-1.5 text-red-600 text-sm">
                <AlertTriangle className="w-4 h-4" /> فشل الاتصال
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Save */}
      <button
        onClick={handleSave}
        className="flex items-center gap-2 gradient-bg text-white px-8 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity shadow-lg mb-6"
      >
        {saved ? <CheckCircle className="w-5 h-5" /> : <Save className="w-5 h-5" />}
        {saved ? 'تم الحفظ بنجاح ✓' : 'حفظ الإعدادات'}
      </button>

      {/* Apps Script Code Template */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6">
        <div className="flex items-center gap-3 mb-4">
          <Code className="w-5 h-5 text-indigo-500" />
          <h3 className="font-bold text-gray-900">كود Google Apps Script الجاهز</h3>
        </div>
        <p className="text-sm text-gray-500 mb-4">انسخ هذا الكود والصقه في Google Apps Script الخاص بك</p>
        <div className="bg-gray-900 rounded-xl p-5 overflow-x-auto" dir="ltr">
          <pre className="text-green-400 text-xs leading-relaxed font-mono">
{`function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  // Queue System - Batch Processing
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  
  try {
    sheet.appendRow([
      new Date(),
      data.orderNumber,
      data.customerName,
      data.customerPhone,
      data.countryCode,
      data.wilaya,
      data.commune,
      data.address,
      data.deliveryType,
      data.products,
      data.totalAmount,
      data.deliveryFee,
      data.status,
      data.deviceType,
      data.browser,
      data.notes
    ]);
    
    return ContentService
      .createTextOutput(JSON.stringify({status: 'success'}))
      .setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = sheet.getDataRange().getValues();
  
  return ContentService
    .createTextOutput(JSON.stringify({data: data}))
    .setMimeType(ContentService.MimeType.JSON);
}`}
          </pre>
        </div>
        <div className="mt-3 flex items-center gap-2 text-xs text-gray-400">
          <ExternalLink className="w-3.5 h-3.5" />
          <a href="https://script.google.com" target="_blank" rel="noopener noreferrer" className="hover:text-indigo-500 transition-colors">
            افتح Google Apps Script
          </a>
        </div>
      </div>
    </div>
  );
}
