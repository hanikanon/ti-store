import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { generateId, formatPrice } from '../utils/helpers';
import { Product } from '../types';
import { Plus, Package, Edit3, Trash2, X, Save, Image, Search } from 'lucide-react';

export default function ProductsView() {
  const { state, dispatch, currentProducts } = useStore();
  const storeId = state.currentStoreId;
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({
    name: '', description: '', price: '', comparePrice: '', category: '', stock: '', images: '' as string,
  });

  if (!storeId) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const filteredProducts = currentProducts.filter(p =>
    p.name.includes(search) || p.category.includes(search)
  );

  const resetForm = () => {
    setForm({ name: '', description: '', price: '', comparePrice: '', category: '', stock: '', images: '' });
    setEditingProduct(null);
    setShowForm(false);
  };

  const handleEdit = (product: Product) => {
    setForm({
      name: product.name,
      description: product.description,
      price: product.price.toString(),
      comparePrice: product.comparePrice?.toString() || '',
      category: product.category,
      stock: product.stock.toString(),
      images: product.images.join(', '),
    });
    setEditingProduct(product);
    setShowForm(true);
  };

  const handleSave = () => {
    if (!form.name || !form.price) return;

    const productData: Product = {
      id: editingProduct?.id || generateId(),
      name: form.name,
      description: form.description,
      price: parseFloat(form.price),
      comparePrice: form.comparePrice ? parseFloat(form.comparePrice) : undefined,
      images: form.images ? form.images.split(',').map(s => s.trim()).filter(Boolean) : [],
      category: form.category,
      stock: parseInt(form.stock) || 0,
      isActive: true,
      createdAt: editingProduct?.createdAt || new Date().toISOString(),
    };

    if (editingProduct) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: { storeId, product: productData } });
    } else {
      dispatch({ type: 'ADD_PRODUCT', payload: { storeId, product: productData } });
    }
    resetForm();
  };

  const handleDelete = (productId: string) => {
    if (confirm('هل تريد حذف هذا المنتج؟')) {
      dispatch({ type: 'DELETE_PRODUCT', payload: { storeId, productId } });
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">المنتجات</h1>
          <p className="text-gray-500 mt-1">{currentProducts.length} منتج</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="flex items-center gap-2 gradient-bg text-white px-5 py-2.5 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity shadow-md"
        >
          <Plus className="w-4 h-4" />
          إضافة منتج
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="البحث في المنتجات..."
          className="w-full pr-12 pl-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 font-medium">لا توجد منتجات</p>
          <p className="text-gray-400 text-sm mt-1">قم بإضافة منتجك الأول</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map(product => (
            <div key={product.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all group">
              <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-50 flex items-center justify-center relative">
                {product.images.length > 0 ? (
                  <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
                ) : (
                  <Image className="w-12 h-12 text-gray-300" />
                )}
                <div className="absolute top-3 left-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => handleEdit(product)} className="p-2 bg-white rounded-lg shadow-md hover:bg-indigo-50 transition-colors">
                    <Edit3 className="w-4 h-4 text-indigo-600" />
                  </button>
                  <button onClick={() => handleDelete(product.id)} className="p-2 bg-white rounded-lg shadow-md hover:bg-red-50 transition-colors">
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </div>
                {product.category && (
                  <span className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm text-gray-600 text-xs px-3 py-1 rounded-full">
                    {product.category}
                  </span>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 mb-1">{product.name}</h3>
                <p className="text-gray-400 text-sm line-clamp-2 mb-3">{product.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-indigo-600">{formatPrice(product.price)}</span>
                    {product.comparePrice && (
                      <span className="text-sm text-gray-400 line-through">{formatPrice(product.comparePrice)}</span>
                    )}
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${product.stock > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                    {product.stock > 0 ? `${product.stock} متوفر` : 'نفذ'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto animate-fade-in">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">{editingProduct ? 'تعديل المنتج' : 'إضافة منتج جديد'}</h2>
              <button onClick={resetForm} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">اسم المنتج *</label>
                <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder="اسم المنتج" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">الوصف</label>
                <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
                  placeholder="وصف المنتج..." rows={3} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">السعر (د.ج) *</label>
                  <input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })}
                    placeholder="0" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">السعر قبل التخفيض</label>
                  <input type="number" value={form.comparePrice} onChange={e => setForm({ ...form, comparePrice: e.target.value })}
                    placeholder="0" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">الفئة</label>
                  <input type="text" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}
                    placeholder="الفئة" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">المخزون</label>
                  <input type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })}
                    placeholder="0" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">روابط الصور (مفصولة بفاصلة)</label>
                <textarea value={form.images} onChange={e => setForm({ ...form, images: e.target.value })}
                  placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                  rows={2} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none" dir="ltr" />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-100">
              <button onClick={resetForm} className="px-5 py-2.5 rounded-xl text-gray-600 hover:bg-gray-100 transition-colors font-medium text-sm">
                إلغاء
              </button>
              <button onClick={handleSave} disabled={!form.name || !form.price}
                className="flex items-center gap-2 gradient-bg text-white px-6 py-2.5 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-50">
                <Save className="w-4 h-4" />
                {editingProduct ? 'تحديث' : 'حفظ'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
