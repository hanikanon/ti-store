import { useStore } from '../contexts/StoreContext';
import Sidebar from './Sidebar';
import DashboardView from './DashboardView';
import ProductsView from './ProductsView';
import OrdersView from './OrdersView';
import DeliveryView from './DeliveryView';
import DesignView from './DesignView';
import AnalyticsView from './AnalyticsView';
import IntegrationView from './IntegrationView';
import SettingsView from './SettingsView';
import StorePreview from './StorePreview';
import CreateStore from './CreateStore';
import { Menu } from 'lucide-react';

interface Props {
  onLogout: () => void;
}

export default function Dashboard({ onLogout }: Props) {
  const { state, dispatch } = useStore();

  const renderView = () => {
    switch (state.currentView) {
      case 'dashboard': return <DashboardView />;
      case 'products': return <ProductsView />;
      case 'orders': return <OrdersView />;
      case 'delivery': return <DeliveryView />;
      case 'design': return <DesignView />;
      case 'analytics': return <AnalyticsView />;
      case 'integration': return <IntegrationView />;
      case 'settings': return <SettingsView />;
      case 'preview': return <StorePreview />;
      case 'create-store': return <CreateStore />;
      default: return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar onLogout={onLogout} />

      {/* Main content */}
      <div className={`transition-all duration-300 ${state.sidebarOpen ? 'lg:mr-72' : 'lg:mr-20'}`}>
        {/* Top bar */}
        <div className="bg-white border-b border-gray-100 px-6 py-3 flex items-center justify-between sticky top-0 z-30">
          <button
            onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
          <div className="flex items-center gap-3">
            <div className="text-left">
              <p className="text-sm font-medium text-gray-700">مرحباً بك</p>
              <p className="text-xs text-gray-400">لوحة إدارة المتاجر</p>
            </div>
            <div className="w-9 h-9 gradient-bg rounded-xl flex items-center justify-center text-white font-bold text-sm">
              A
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {renderView()}
        </div>
      </div>
    </div>
  );
}
