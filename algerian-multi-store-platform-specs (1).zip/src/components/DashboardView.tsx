import { useStore } from '../contexts/StoreContext';
import { Package, ClipboardList, CheckCircle, XCircle, Phone, PhoneCall, Store, Plus } from 'lucide-react';
import { formatPrice } from '../utils/helpers';

export default function DashboardView() {
  const { currentStore, currentProducts, currentOrders, dispatch } = useStore();

  if (!currentStore) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center animate-fade-in">
          <div className="w-24 h-24 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <Store className="w-12 h-12 text-indigo-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">مرحباً بك في DZ Store</h2>
          <p className="text-gray-500 mb-8 max-w-md">
            لم تقم بإنشاء أي متجر بعد. ابدأ بإنشاء متجرك الأول واستمتع بتجربة التجارة الإلكترونية
          </p>
          <button
            onClick={() => dispatch({ type: 'SET_VIEW', payload: 'create-store' })}
            className="inline-flex items-center gap-2 gradient-bg text-white px-8 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity shadow-lg"
          >
            <Plus className="w-5 h-5" />
            إنشاء متجر جديد
          </button>
        </div>
      </div>
    );
  }

  const confirmedOrders = currentOrders.filter(o => o.status === 'مؤكدة');
  const cancelledOrders = currentOrders.filter(o => o.status === 'ملغاة');
  const call1Orders = currentOrders.filter(o => o.status === 'إتصال 1');
  const call2Orders = currentOrders.filter(o => o.status === 'إتصال 2');

  const totalRevenue = confirmedOrders.reduce((sum, o) => sum + o.totalAmount, 0);

  const stats = [
    { label: 'إجمالي المنتجات', value: currentProducts.length, icon: <Package className="w-6 h-6" />, color: 'bg-indigo-50 text-indigo-600' },
    { label: 'إجمالي الطلبات', value: currentOrders.length, icon: <ClipboardList className="w-6 h-6" />, color: 'bg-purple-50 text-purple-600' },
    { label: 'طلبات مؤكدة', value: confirmedOrders.length, icon: <CheckCircle className="w-6 h-6" />, color: 'bg-emerald-50 text-emerald-600' },
    { label: 'طلبات ملغاة', value: cancelledOrders.length, icon: <XCircle className="w-6 h-6" />, color: 'bg-red-50 text-red-600' },
    { label: 'إتصال 1', value: call1Orders.length, icon: <Phone className="w-6 h-6" />, color: 'bg-amber-50 text-amber-600' },
    { label: 'إتصال 2', value: call2Orders.length, icon: <PhoneCall className="w-6 h-6" />, color: 'bg-blue-50 text-blue-600' },
  ];

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">لوحة التحكم</h1>
        <p className="text-gray-500 mt-1">نظرة عامة على متجر <span className="font-semibold text-indigo-600">{currentStore.name}</span></p>
      </div>

      {/* Revenue Card */}
      <div className="gradient-bg rounded-2xl p-6 mb-8 text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-0 left-0 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
          <div className="absolute bottom-0 right-0 w-56 h-56 bg-purple-300/10 rounded-full blur-2xl"></div>
        </div>
        <div className="relative">
          <p className="text-indigo-100 text-sm mb-1">إجمالي الإيرادات (الطلبات المؤكدة)</p>
          <p className="text-4xl font-black">{formatPrice(totalRevenue)}</p>
          <p className="text-indigo-200 text-sm mt-2">من {confirmedOrders.length} طلب مؤكد</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white rounded-2xl p-5 border border-gray-100 hover:shadow-md transition-shadow">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${stat.color}`}>
              {stat.icon}
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-gray-500 text-sm mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="p-5 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900">آخر الطلبات</h3>
          <button
            onClick={() => dispatch({ type: 'SET_VIEW', payload: 'orders' })}
            className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
          >
            عرض الكل
          </button>
        </div>
        {currentOrders.length === 0 ? (
          <div className="p-10 text-center">
            <ClipboardList className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-400">لا توجد طلبات حتى الآن</p>
            <p className="text-gray-300 text-sm mt-1">الطلبات تأتي فقط من العملاء الحقيقيين عبر المتجر</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {currentOrders.slice(0, 5).map(order => (
              <div key={order.id} className="p-4 hover:bg-gray-50 transition-colors flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-gray-500 text-sm font-mono">
                    #{order.orderNumber.slice(-4)}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm">{order.customerName}</p>
                    <p className="text-gray-400 text-xs">{order.wilaya} - {order.commune}</p>
                  </div>
                </div>
                <div className="text-left">
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium border ${
                    order.status === 'مؤكدة' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                    order.status === 'ملغاة' ? 'bg-red-50 text-red-700 border-red-200' :
                    order.status === 'إتصال 1' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                    'bg-blue-50 text-blue-700 border-blue-200'
                  }`}>
                    {order.status}
                  </span>
                  <p className="text-gray-500 text-xs mt-1">{formatPrice(order.totalAmount)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
