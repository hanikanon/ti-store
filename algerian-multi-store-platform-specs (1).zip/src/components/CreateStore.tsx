import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { generateId } from '../utils/helpers';
import { Store as StoreType } from '../types';
import { Store, ArrowLeft, Palette, Globe, Settings } from 'lucide-react';

export default function CreateStore() {
  const { dispatch } = useStore();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: '',
    slug: '',
    description: '',
    primaryColor: '#6366f1',
    secondaryColor: '#f59e0b',
    accentColor: '#10b981',
    phone: '',
    email: '',
    facebook: '',
    instagram: '',
    googleAnalyticsId: '',
    googleSheetId: '',
    googleAppsScriptUrl: '',
  });

  const handleSubmit = () => {
    if (!form.name.trim()) return;
    
    const store: StoreType = {
      id: generateId(),
      name: form.name,
      slug: form.slug || form.name.toLowerCase().replace(/\s+/g, '-'),
      description: form.description,
      primaryColor: form.primaryColor,
      secondaryColor: form.secondaryColor,
      accentColor: form.accentColor,
      fontFamily: 'Cairo',
      currency: 'د.ج',
      phone: form.phone,
      email: form.email,
      facebook: form.facebook,
      instagram: form.instagram,
      googleAnalyticsId: form.googleAnalyticsId,
      googleSheetId: form.googleSheetId,
      googleAppsScriptUrl: form.googleAppsScriptUrl,
      isActive: true,
      createdAt: new Date().toISOString(),
      settings: {
        showCart: true,
        cartStyle: 'sidebar',
        productCardStyle: 'modern',
        headerStyle: 'modern',
        footerEnabled: true,
        buttonStyle: 'rounded',
        buttonColor: form.primaryColor,
        buttonTextColor: '#ffffff',
      },
    };

    dispatch({ type: 'ADD_STORE', payload: store });
    dispatch({ type: 'SET_VIEW', payload: 'dashboard' });
  };

  return (
    <div className="max-w-3xl mx-auto animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">إنشاء متجر جديد</h1>
        <p className="text-gray-500 mt-1">قم بإعداد متجرك الإلكتروني في دقائق</p>
      </div>

      {/* Steps */}
      <div className="flex items-center gap-4 mb-8">
        {[
          { num: 1, label: 'معلومات المتجر', icon: <Store className="w-4 h-4" /> },
          { num: 2, label: 'التصميم', icon: <Palette className="w-4 h-4" /> },
          { num: 3, label: 'الربط', icon: <Globe className="w-4 h-4" /> },
        ].map(s => (
          <button
            key={s.num}
            onClick={() => setStep(s.num)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              step === s.num ? 'gradient-bg text-white shadow-md' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
            }`}
          >
            {s.icon}
            {s.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 p-8">
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">اسم المتجر *</label>
              <input
                type="text"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="مثال: متجر الأناقة"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">رابط المتجر (Slug)</label>
              <input
                type="text"
                value={form.slug}
                onChange={e => setForm({ ...form, slug: e.target.value })}
                placeholder="elegance-store"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">وصف المتجر</label>
              <textarea
                value={form.description}
                onChange={e => setForm({ ...form, description: e.target.value })}
                placeholder="وصف مختصر لمتجرك..."
                rows={3}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all resize-none"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">رقم الهاتف</label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })}
                  placeholder="0555123456"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  placeholder="store@example.com"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">فيسبوك</label>
                <input
                  type="url"
                  value={form.facebook}
                  onChange={e => setForm({ ...form, facebook: e.target.value })}
                  placeholder="https://facebook.com/..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  dir="ltr"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">إنستغرام</label>
                <input
                  type="url"
                  value={form.instagram}
                  onChange={e => setForm({ ...form, instagram: e.target.value })}
                  placeholder="https://instagram.com/..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  dir="ltr"
                />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-4">ألوان المتجر</label>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <label className="block text-xs text-gray-500 mb-2">اللون الرئيسي</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={form.primaryColor}
                      onChange={e => setForm({ ...form, primaryColor: e.target.value })}
                      className="w-12 h-12 rounded-xl border-2 border-gray-200 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={form.primaryColor}
                      onChange={e => setForm({ ...form, primaryColor: e.target.value })}
                      className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-2">اللون الثانوي</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={form.secondaryColor}
                      onChange={e => setForm({ ...form, secondaryColor: e.target.value })}
                      className="w-12 h-12 rounded-xl border-2 border-gray-200 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={form.secondaryColor}
                      onChange={e => setForm({ ...form, secondaryColor: e.target.value })}
                      className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-2">لون التمييز</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={form.accentColor}
                      onChange={e => setForm({ ...form, accentColor: e.target.value })}
                      className="w-12 h-12 rounded-xl border-2 border-gray-200 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={form.accentColor}
                      onChange={e => setForm({ ...form, accentColor: e.target.value })}
                      className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm"
                      dir="ltr"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Preview */}
            <div className="mt-8">
              <label className="block text-sm font-semibold text-gray-700 mb-4">معاينة الألوان</label>
              <div className="border border-gray-200 rounded-2xl overflow-hidden">
                <div className="h-3" style={{ background: form.primaryColor }}></div>
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold" style={{ background: form.primaryColor }}>
                      {form.name?.[0] || 'M'}
                    </div>
                    <span className="font-bold" style={{ color: form.primaryColor }}>{form.name || 'اسم المتجر'}</span>
                  </div>
                  <div className="flex gap-3">
                    <button className="px-6 py-2 rounded-xl text-white text-sm font-medium" style={{ background: form.primaryColor }}>
                      اشتري الآن
                    </button>
                    <button className="px-6 py-2 rounded-xl text-white text-sm font-medium" style={{ background: form.secondaryColor }}>
                      أضف للسلة
                    </button>
                    <button className="px-6 py-2 rounded-xl text-white text-sm font-medium" style={{ background: form.accentColor }}>
                      تفاصيل
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
              <div className="flex items-start gap-3">
                <Settings className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-amber-800">إعدادات اختيارية</p>
                  <p className="text-xs text-amber-600 mt-1">يمكنك إضافة هذه الإعدادات لاحقاً من صفحة الإعدادات</p>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Google Analytics Tracking ID</label>
              <input
                type="text"
                value={form.googleAnalyticsId}
                onChange={e => setForm({ ...form, googleAnalyticsId: e.target.value })}
                placeholder="G-XXXXXXXXXX"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Google Sheet ID</label>
              <input
                type="text"
                value={form.googleSheetId}
                onChange={e => setForm({ ...form, googleSheetId: e.target.value })}
                placeholder="1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                dir="ltr"
              />
              <p className="text-xs text-gray-400 mt-2">يمكنك الحصول عليه من رابط Google Sheet الخاص بك</p>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Google Apps Script URL</label>
              <input
                type="text"
                value={form.googleAppsScriptUrl}
                onChange={e => setForm({ ...form, googleAppsScriptUrl: e.target.value })}
                placeholder="https://script.google.com/macros/s/xxx/exec"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                dir="ltr"
              />
              <p className="text-xs text-gray-400 mt-2">رابط API الخاص بـ Google Apps Script لمعالجة الطلبات</p>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
          {step > 1 ? (
            <button
              onClick={() => setStep(step - 1)}
              className="px-6 py-2.5 rounded-xl text-gray-600 hover:bg-gray-100 transition-colors font-medium text-sm"
            >
              السابق
            </button>
          ) : (
            <button
              onClick={() => dispatch({ type: 'SET_VIEW', payload: 'dashboard' })}
              className="px-6 py-2.5 rounded-xl text-gray-600 hover:bg-gray-100 transition-colors font-medium text-sm"
            >
              إلغاء
            </button>
          )}
          
          {step < 3 ? (
            <button
              onClick={() => setStep(step + 1)}
              className="flex items-center gap-2 gradient-bg text-white px-6 py-2.5 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
            >
              التالي
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!form.name.trim()}
              className="flex items-center gap-2 gradient-bg text-white px-8 py-2.5 rounded-xl font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
            >
              إنشاء المتجر
              <Store className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
