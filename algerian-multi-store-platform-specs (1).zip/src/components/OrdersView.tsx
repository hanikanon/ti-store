import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { formatPrice, formatDate, getStatusColor } from '../utils/helpers';
import { OrderStatus } from '../types';
import { ClipboardList, Search, Eye, X, Phone, Monitor, MapPin, ChevronDown } from 'lucide-react';

const ORDER_STATUSES: OrderStatus[] = ['مؤكدة', 'ملغاة', 'إتصال 1', 'إتصال 2'];

export default function OrdersView() {
  const { state, dispatch, currentOrders } = useStore();
  const storeId = state.currentStoreId;
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const [showStatusDropdown, setShowStatusDropdown] = useState<string | null>(null);

  if (!storeId) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const filtered = currentOrders.filter(o => {
    const matchSearch = !search || o.customerName.includes(search) || o.customerPhone.includes(search) || o.orderNumber.includes(search);
    const matchStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusCounts = {
    all: currentOrders.length,
    'مؤكدة': currentOrders.filter(o => o.status === 'مؤكدة').length,
    'ملغاة': currentOrders.filter(o => o.status === 'ملغاة').length,
    'إتصال 1': currentOrders.filter(o => o.status === 'إتصال 1').length,
    'إتصال 2': currentOrders.filter(o => o.status === 'إتصال 2').length,
  };

  const orderDetail = selectedOrder ? currentOrders.find(o => o.id === selectedOrder) : null;

  const updateStatus = (orderId: string, status: OrderStatus) => {
    dispatch({ type: 'UPDATE_ORDER_STATUS', payload: { storeId, orderId, status } });
    setShowStatusDropdown(null);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">الطلبات</h1>
        <p className="text-gray-500 mt-1">إدارة جميع الطلبات الواردة</p>
      </div>

      {/* Status Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {(['all', ...ORDER_STATUSES] as const).map(status => (
          <button
            key={status}
            onClick={() => setStatusFilter(status)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              statusFilter === status
                ? 'gradient-bg text-white shadow-md'
                : 'bg-white border border-gray-200 text-gray-600 hover:border-indigo-200 hover:text-indigo-600'
            }`}
          >
            {status === 'all' ? 'الكل' : status}
            <span className={`text-xs px-2 py-0.5 rounded-full ${
              statusFilter === status ? 'bg-white/20' : 'bg-gray-100'
            }`}>
              {statusCounts[status]}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="بحث بالاسم أو الهاتف أو رقم الطلب..."
          className="w-full pr-12 pl-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Orders Table */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
          <ClipboardList className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 font-medium">لا توجد طلبات</p>
          <p className="text-gray-400 text-sm mt-1">الطلبات تأتي فقط من العملاء الحقيقيين عبر واجهة المتجر</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">رقم الطلب</th>
                  <th className="text-right px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">العميل</th>
                  <th className="text-right px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">الولاية</th>
                  <th className="text-right px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">المبلغ</th>
                  <th className="text-right px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">الحالة</th>
                  <th className="text-right px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">التاريخ</th>
                  <th className="text-center px-5 py-3.5 text-xs font-semibold text-gray-500 uppercase">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-5 py-4">
                      <span className="font-mono text-sm text-gray-600">#{order.orderNumber}</span>
                    </td>
                    <td className="px-5 py-4">
                      <p className="font-medium text-gray-900 text-sm">{order.customerName}</p>
                      <p className="text-gray-400 text-xs mt-0.5" dir="ltr">{order.countryCode}{order.customerPhone}</p>
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-sm text-gray-600">{order.wilaya}</p>
                      <p className="text-xs text-gray-400">{order.commune}</p>
                    </td>
                    <td className="px-5 py-4">
                      <span className="font-semibold text-gray-900 text-sm">{formatPrice(order.totalAmount + order.deliveryFee)}</span>
                    </td>
                    <td className="px-5 py-4 relative">
                      <button
                        onClick={() => setShowStatusDropdown(showStatusDropdown === order.id ? null : order.id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border ${getStatusColor(order.status)} cursor-pointer hover:opacity-80 transition-opacity`}
                      >
                        {order.status}
                        <ChevronDown className="w-3 h-3" />
                      </button>
                      {showStatusDropdown === order.id && (
                        <div className="absolute top-full right-0 mt-1 bg-white rounded-xl shadow-xl border border-gray-100 py-1 z-50 min-w-[140px]">
                          {ORDER_STATUSES.map(status => (
                            <button
                              key={status}
                              onClick={() => updateStatus(order.id, status)}
                              className={`w-full text-right px-4 py-2 text-sm hover:bg-gray-50 transition-colors ${
                                order.status === status ? 'text-indigo-600 font-medium bg-indigo-50' : 'text-gray-600'
                              }`}
                            >
                              {status}
                            </button>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-xs text-gray-400">{formatDate(order.createdAt)}</span>
                    </td>
                    <td className="px-5 py-4 text-center">
                      <button
                        onClick={() => setSelectedOrder(order.id)}
                        className="p-2 hover:bg-indigo-50 rounded-lg transition-colors text-gray-400 hover:text-indigo-600"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Order Detail Modal */}
      {orderDetail && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-fade-in">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-900">تفاصيل الطلب #{orderDetail.orderNumber}</h2>
              <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              {/* Status */}
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <span className="text-sm font-medium text-gray-600">حالة الطلب</span>
                <span className={`px-4 py-1.5 rounded-full text-sm font-medium border ${getStatusColor(orderDetail.status)}`}>
                  {orderDetail.status}
                </span>
              </div>

              {/* Customer Info */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-indigo-500" /> معلومات العميل
                </h3>
                <div className="grid grid-cols-2 gap-4 bg-gray-50 rounded-xl p-4">
                  <div>
                    <span className="text-xs text-gray-400">الاسم</span>
                    <p className="font-medium text-gray-900">{orderDetail.customerName}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-400">الهاتف</span>
                    <p className="font-medium text-gray-900" dir="ltr">{orderDetail.countryCode} {orderDetail.customerPhone}</p>
                  </div>
                </div>
              </div>

              {/* Address */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-indigo-500" /> العنوان
                </h3>
                <div className="grid grid-cols-3 gap-4 bg-gray-50 rounded-xl p-4">
                  <div>
                    <span className="text-xs text-gray-400">الولاية</span>
                    <p className="font-medium text-gray-900">{orderDetail.wilaya}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-400">البلدية</span>
                    <p className="font-medium text-gray-900">{orderDetail.commune}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-400">نوع التوصيل</span>
                    <p className="font-medium text-gray-900">{orderDetail.deliveryType === 'home' ? '🏠 منزل' : '🏢 مكتب'}</p>
                  </div>
                </div>
                {orderDetail.address && (
                  <p className="mt-2 text-sm text-gray-600 bg-gray-50 rounded-xl p-3">{orderDetail.address}</p>
                )}
              </div>

              {/* Device Info */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Monitor className="w-4 h-4 text-indigo-500" /> معلومات الجهاز
                </h3>
                <div className="grid grid-cols-2 gap-4 bg-gray-50 rounded-xl p-4">
                  <div>
                    <span className="text-xs text-gray-400">نوع الجهاز</span>
                    <p className="font-medium text-gray-900">{orderDetail.deviceType}</p>
                  </div>
                  <div>
                    <span className="text-xs text-gray-400">المتصفح</span>
                    <p className="font-medium text-gray-900">{orderDetail.browser}</p>
                  </div>
                </div>
              </div>

              {/* Products */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">المنتجات</h3>
                <div className="space-y-2">
                  {orderDetail.products.map((p, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{p.productName}</p>
                        {p.variant && <p className="text-xs text-gray-400">{p.variant}</p>}
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-gray-900 text-sm">{formatPrice(p.price * p.quantity)}</p>
                        <p className="text-xs text-gray-400">{p.quantity} × {formatPrice(p.price)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total */}
              <div className="border-t border-gray-100 pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">المجموع الفرعي</span>
                  <span className="font-medium">{formatPrice(orderDetail.totalAmount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">رسوم التوصيل</span>
                  <span className="font-medium">{formatPrice(orderDetail.deliveryFee)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-100">
                  <span className="text-gray-900">الإجمالي</span>
                  <span className="text-indigo-600">{formatPrice(orderDetail.totalAmount + orderDetail.deliveryFee)}</span>
                </div>
              </div>

              {/* Notes */}
              {orderDetail.notes && (
                <div className="bg-amber-50 rounded-xl p-4">
                  <span className="text-xs text-amber-600 font-medium">ملاحظات</span>
                  <p className="text-sm text-amber-800 mt-1">{orderDetail.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
