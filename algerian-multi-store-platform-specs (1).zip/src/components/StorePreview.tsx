import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { CartItem, Order } from '../types';
import { formatPrice, generateId, generateOrderNumber, getDeviceInfo } from '../utils/helpers';
import { ShoppingCart, X, Plus, Minus, ArrowRight, ChevronLeft, Phone, MapPin, User, FileText, CheckCircle, Truck, Home, Building2 } from 'lucide-react';

export default function StorePreview() {
  const { state, dispatch, currentStore, currentProducts, currentDeliveryPrices } = useStore();
  const storeId = state.currentStoreId;
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [checkoutForm, setCheckoutForm] = useState({
    name: '', phone: '', countryCode: '+213', wilaya: '', commune: '', address: '', deliveryType: 'home' as 'home' | 'office', notes: '',
  });

  if (!currentStore || !storeId) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const addToCart = (productId: string) => {
    const product = currentProducts.find(p => p.id === productId);
    if (!product) return;
    setCart(prev => {
      const existing = prev.find(c => c.product.id === productId);
      if (existing) return prev.map(c => c.product.id === productId ? { ...c, quantity: c.quantity + 1 } : c);
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(c => c.product.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(c => {
      if (c.product.id !== productId) return c;
      const newQty = c.quantity + delta;
      return newQty < 1 ? c : { ...c, quantity: newQty };
    }));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const selectedWilaya = currentDeliveryPrices.find(w => w.nameAr === checkoutForm.wilaya);
  const deliveryFee = selectedWilaya
    ? (checkoutForm.deliveryType === 'home' ? selectedWilaya.homeDeliveryPrice : selectedWilaya.officeDeliveryPrice)
    : 0;

  const selectedProductData = selectedProduct ? currentProducts.find(p => p.id === selectedProduct) : null;

  const handleSubmitOrder = async () => {
    if (!checkoutForm.name || !checkoutForm.phone || !checkoutForm.wilaya || cart.length === 0) return;

    const { deviceType, browser } = getDeviceInfo();
    const order: Order = {
      id: generateId(),
      orderNumber: generateOrderNumber(),
      customerName: checkoutForm.name,
      customerPhone: checkoutForm.phone,
      countryCode: checkoutForm.countryCode,
      wilaya: checkoutForm.wilaya,
      commune: checkoutForm.commune,
      address: checkoutForm.address,
      products: cart.map(c => ({
        productId: c.product.id,
        productName: c.product.name,
        quantity: c.quantity,
        price: c.product.price,
        variant: c.variant,
      })),
      totalAmount: cartTotal,
      deliveryFee,
      deliveryType: checkoutForm.deliveryType,
      status: 'إتصال 1',
      deviceType,
      browser,
      createdAt: new Date().toISOString(),
      notes: checkoutForm.notes,
    };

    // Send to Google Apps Script if configured
    if (currentStore.googleAppsScriptUrl) {
      try {
        await fetch(currentStore.googleAppsScriptUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(order),
          mode: 'no-cors',
        });
      } catch (err) {
        console.error('Failed to send to Google Apps Script:', err);
      }
    }

    dispatch({ type: 'ADD_ORDER', payload: { storeId, order } });
    setCart([]);
    setShowCheckout(false);
    setShowCart(false);
    setOrderSuccess(true);
    setCheckoutForm({ name: '', phone: '', countryCode: '+213', wilaya: '', commune: '', address: '', deliveryType: 'home', notes: '' });
    setTimeout(() => setOrderSuccess(false), 5000);
  };

  const btnRadius = currentStore.settings.buttonStyle === 'pill' ? '9999px' : currentStore.settings.buttonStyle === 'square' ? '4px' : '12px';

  return (
    <div className="animate-fade-in">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">معاينة المتجر</h1>
          <p className="text-gray-500 mt-1 text-sm">هكذا يظهر متجرك للعملاء</p>
        </div>
        <div className="flex items-center gap-2">
          {cart.length > 0 && (
            <span className="text-sm text-gray-500">{cart.length} منتج في السلة</span>
          )}
        </div>
      </div>

      <div className="bg-gray-100 rounded-2xl p-4">
        <div className="bg-white rounded-xl overflow-hidden shadow-sm max-w-4xl mx-auto">
          {/* Success Message */}
          {orderSuccess && (
            <div className="bg-emerald-500 text-white p-4 flex items-center justify-center gap-3">
              <CheckCircle className="w-5 h-5" />
              <span className="font-medium">تم إرسال طلبك بنجاح! سنتصل بك قريباً للتأكيد</span>
            </div>
          )}

          {/* Announcement Bar */}
          {currentStore.settings.announcementBar && (
            <div className="py-2.5 px-4 text-center text-white text-sm font-medium" style={{ background: currentStore.settings.announcementBarColor || currentStore.primaryColor }}>
              {currentStore.settings.announcementBar}
            </div>
          )}

          {/* Header */}
          <header className="p-4 border-b border-gray-100 sticky top-0 bg-white z-10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold" style={{ background: currentStore.primaryColor }}>
                  {currentStore.name[0]}
                </div>
                <div>
                  <span className="font-bold" style={{ color: currentStore.primaryColor }}>{currentStore.name}</span>
                  {currentStore.description && <p className="text-xs text-gray-400">{currentStore.description}</p>}
                </div>
              </div>
              {currentStore.settings.showCart && (
                <button onClick={() => setShowCart(true)} className="relative p-2 rounded-xl hover:bg-gray-50 transition-colors">
                  <ShoppingCart className="w-6 h-6" style={{ color: currentStore.primaryColor }} />
                  {cart.length > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full text-white text-xs flex items-center justify-center font-bold" style={{ background: currentStore.secondaryColor }}>
                      {cart.reduce((s, c) => s + c.quantity, 0)}
                    </span>
                  )}
                </button>
              )}
            </div>
          </header>

          {/* Products */}
          <div className="p-6">
            {selectedProductData ? (
              // Product Detail
              <div className="animate-fade-in">
                <button onClick={() => setSelectedProduct(null)} className="flex items-center gap-1 text-sm text-gray-500 mb-4 hover:text-gray-700">
                  <ChevronLeft className="w-4 h-4" />
                  العودة للمنتجات
                </button>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="bg-gradient-to-br from-gray-100 to-gray-50 rounded-2xl h-72 flex items-center justify-center">
                    {selectedProductData.images.length > 0 ? (
                      <img src={selectedProductData.images[0]} alt={selectedProductData.name} className="w-full h-full object-cover rounded-2xl" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
                    ) : (
                      <span className="text-6xl">📦</span>
                    )}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">{selectedProductData.name}</h2>
                    {selectedProductData.category && (
                      <span className="inline-block px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 mb-4">{selectedProductData.category}</span>
                    )}
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-3xl font-black" style={{ color: currentStore.primaryColor }}>{formatPrice(selectedProductData.price)}</span>
                      {selectedProductData.comparePrice && (
                        <span className="text-lg text-gray-400 line-through">{formatPrice(selectedProductData.comparePrice)}</span>
                      )}
                    </div>
                    {selectedProductData.description && (
                      <p className="text-gray-600 mb-6 leading-relaxed">{selectedProductData.description}</p>
                    )}
                    <div className="flex items-center gap-3 mb-4">
                      <span className={`text-sm px-3 py-1 rounded-full ${selectedProductData.stock > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                        {selectedProductData.stock > 0 ? `✓ متوفر (${selectedProductData.stock})` : '✕ غير متوفر'}
                      </span>
                    </div>
                    <button
                      onClick={() => addToCart(selectedProductData.id)}
                      disabled={selectedProductData.stock <= 0}
                      className="w-full py-3 font-bold text-sm transition-opacity hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
                      style={{ background: currentStore.settings.buttonColor, color: currentStore.settings.buttonTextColor, borderRadius: btnRadius }}
                    >
                      <ShoppingCart className="w-5 h-5" />
                      أضف إلى السلة
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              // Products Grid
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-4">منتجاتنا</h3>
                {currentProducts.length === 0 ? (
                  <div className="text-center py-16">
                    <span className="text-5xl mb-4 block">🛍️</span>
                    <p className="text-gray-500">لا توجد منتجات بعد</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {currentProducts.filter(p => p.isActive).map(product => (
                      <div key={product.id} className={`border border-gray-100 overflow-hidden hover:shadow-md transition-all cursor-pointer group ${
                        currentStore.settings.productCardStyle === 'modern' ? 'rounded-2xl' : 'rounded-xl'
                      }`} onClick={() => setSelectedProduct(product.id)}>
                        <div className="h-40 bg-gradient-to-br from-gray-100 to-gray-50 flex items-center justify-center relative overflow-hidden">
                          {product.images.length > 0 ? (
                            <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
                          ) : (
                            <span className="text-3xl">📦</span>
                          )}
                          {product.comparePrice && (
                            <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-xs font-bold text-white" style={{ background: currentStore.secondaryColor }}>
                              -{Math.round((1 - product.price / product.comparePrice) * 100)}%
                            </span>
                          )}
                        </div>
                        <div className="p-3">
                          <h4 className="font-bold text-sm text-gray-900 mb-1 line-clamp-1">{product.name}</h4>
                          {currentStore.settings.productCardStyle === 'detailed' && product.description && (
                            <p className="text-xs text-gray-400 line-clamp-2 mb-2">{product.description}</p>
                          )}
                          <div className="flex items-center gap-2">
                            <span className="text-base font-black" style={{ color: currentStore.primaryColor }}>{formatPrice(product.price)}</span>
                            {product.comparePrice && (
                              <span className="text-xs text-gray-400 line-through">{formatPrice(product.comparePrice)}</span>
                            )}
                          </div>
                          {currentStore.settings.productCardStyle !== 'minimal' && (
                            <button
                              onClick={e => { e.stopPropagation(); addToCart(product.id); }}
                              className="w-full mt-2 py-2 text-xs font-bold transition-opacity hover:opacity-80"
                              style={{ background: currentStore.settings.buttonColor, color: currentStore.settings.buttonTextColor, borderRadius: btnRadius }}
                            >
                              أضف للسلة
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          {currentStore.settings.footerEnabled && (
            <footer className="p-6 bg-gray-50 border-t border-gray-100">
              <div className="flex flex-col items-center gap-2">
                <div className="flex items-center gap-4">
                  {currentStore.phone && <span className="text-sm text-gray-500 flex items-center gap-1"><Phone className="w-3.5 h-3.5" />{currentStore.phone}</span>}
                </div>
                <p className="text-xs text-gray-400">© {new Date().getFullYear()} {currentStore.name} - جميع الحقوق محفوظة</p>
                <p className="text-xs text-gray-300">مدعوم من DZ Store</p>
              </div>
            </footer>
          )}
        </div>
      </div>

      {/* Cart Sidebar */}
      {showCart && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCart(false)} />
          <div className="absolute top-0 left-0 h-full w-full max-w-md bg-white shadow-2xl animate-slide-in overflow-y-auto">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <ShoppingCart className="w-5 h-5" style={{ color: currentStore.primaryColor }} />
                السلة ({cart.reduce((s, c) => s + c.quantity, 0)})
              </h3>
              <button onClick={() => setShowCart(false)} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5 text-gray-400" /></button>
            </div>

            {cart.length === 0 ? (
              <div className="p-10 text-center">
                <span className="text-4xl block mb-3">🛒</span>
                <p className="text-gray-500">السلة فارغة</p>
              </div>
            ) : (
              <>
                <div className="p-4 space-y-3">
                  {cart.map(item => (
                    <div key={item.product.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                      <div className="w-14 h-14 bg-white rounded-lg flex items-center justify-center flex-shrink-0">
                        <span className="text-xl">📦</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm text-gray-900 truncate">{item.product.name}</p>
                        <p className="text-sm font-bold" style={{ color: currentStore.primaryColor }}>{formatPrice(item.product.price)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => updateQuantity(item.product.id, -1)} className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center">
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.product.id, 1)} className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center">
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <button onClick={() => removeFromCart(item.product.id)} className="p-1 text-red-400 hover:text-red-600">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-gray-100">
                  <div className="flex justify-between mb-4">
                    <span className="text-gray-500">المجموع</span>
                    <span className="font-bold text-lg" style={{ color: currentStore.primaryColor }}>{formatPrice(cartTotal)}</span>
                  </div>
                  <button
                    onClick={() => { setShowCart(false); setShowCheckout(true); }}
                    className="w-full py-3 font-bold text-sm flex items-center justify-center gap-2 transition-opacity hover:opacity-90"
                    style={{ background: currentStore.settings.buttonColor, color: currentStore.settings.buttonTextColor, borderRadius: btnRadius }}
                  >
                    إتمام الطلب
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {showCheckout && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto animate-fade-in">
            <div className="flex items-center justify-between p-5 border-b border-gray-100">
              <h3 className="font-bold text-gray-900">إتمام الطلب</h3>
              <button onClick={() => setShowCheckout(false)} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-gray-400" /> الاسم الكامل *
                </label>
                <input type="text" value={checkoutForm.name} onChange={e => setCheckoutForm({ ...checkoutForm, name: e.target.value })}
                  placeholder="الاسم الكامل" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Phone className="w-4 h-4 text-gray-400" /> رقم الهاتف *
                </label>
                <div className="flex gap-2">
                  <select value={checkoutForm.countryCode} onChange={e => setCheckoutForm({ ...checkoutForm, countryCode: e.target.value })}
                    className="px-3 py-2.5 border border-gray-200 rounded-xl bg-white outline-none text-sm w-24" dir="ltr">
                    <option value="+213">+213</option>
                  </select>
                  <input type="tel" value={checkoutForm.phone} onChange={e => setCheckoutForm({ ...checkoutForm, phone: e.target.value })}
                    placeholder="0555123456" className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-gray-400" /> الولاية *
                </label>
                <select value={checkoutForm.wilaya} onChange={e => setCheckoutForm({ ...checkoutForm, wilaya: e.target.value, commune: '' })}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl bg-white outline-none">
                  <option value="">اختر الولاية</option>
                  {currentDeliveryPrices.filter(w => w.isActive).map(w => (
                    <option key={w.code} value={w.nameAr}>{w.code} - {w.nameAr}</option>
                  ))}
                </select>
              </div>
              {selectedWilaya && (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1.5">البلدية</label>
                  <select value={checkoutForm.commune} onChange={e => setCheckoutForm({ ...checkoutForm, commune: e.target.value })}
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl bg-white outline-none">
                    <option value="">اختر البلدية</option>
                    {selectedWilaya.communes.map(c => (
                      <option key={c.nameAr} value={c.nameAr}>{c.nameAr}</option>
                    ))}
                  </select>
                </div>
              )}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-gray-400" /> نوع التوصيل
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setCheckoutForm({ ...checkoutForm, deliveryType: 'home' })}
                    className={`flex items-center gap-2 p-3 rounded-xl border-2 transition-all ${
                      checkoutForm.deliveryType === 'home' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200'
                    }`}
                  >
                    <Home className="w-5 h-5" />
                    <div className="text-right">
                      <p className="text-sm font-medium">المنزل</p>
                      {selectedWilaya && <p className="text-xs text-gray-500">{formatPrice(selectedWilaya.homeDeliveryPrice)}</p>}
                    </div>
                  </button>
                  <button
                    onClick={() => setCheckoutForm({ ...checkoutForm, deliveryType: 'office' })}
                    className={`flex items-center gap-2 p-3 rounded-xl border-2 transition-all ${
                      checkoutForm.deliveryType === 'office' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200'
                    }`}
                  >
                    <Building2 className="w-5 h-5" />
                    <div className="text-right">
                      <p className="text-sm font-medium">المكتب</p>
                      {selectedWilaya && <p className="text-xs text-gray-500">{formatPrice(selectedWilaya.officeDeliveryPrice)}</p>}
                    </div>
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">العنوان التفصيلي</label>
                <input type="text" value={checkoutForm.address} onChange={e => setCheckoutForm({ ...checkoutForm, address: e.target.value })}
                  placeholder="شارع، حي، عمارة..." className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-gray-400" /> ملاحظات (اختياري)
                </label>
                <textarea value={checkoutForm.notes} onChange={e => setCheckoutForm({ ...checkoutForm, notes: e.target.value })}
                  placeholder="أي ملاحظات إضافية..." rows={2}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none" />
              </div>

              {/* Order Summary */}
              <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                <h4 className="font-bold text-sm text-gray-900 mb-2">ملخص الطلب</h4>
                {cart.map(item => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">{item.product.name} × {item.quantity}</span>
                    <span className="font-medium">{formatPrice(item.product.price * item.quantity)}</span>
                  </div>
                ))}
                <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between text-sm">
                  <span className="text-gray-500">التوصيل</span>
                  <span className="font-medium">{formatPrice(deliveryFee)}</span>
                </div>
                <div className="flex justify-between font-bold text-base pt-1">
                  <span>الإجمالي</span>
                  <span style={{ color: currentStore.primaryColor }}>{formatPrice(cartTotal + deliveryFee)}</span>
                </div>
              </div>

              <button
                onClick={handleSubmitOrder}
                disabled={!checkoutForm.name || !checkoutForm.phone || !checkoutForm.wilaya}
                className="w-full py-3 font-bold text-sm transition-opacity hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                style={{ background: currentStore.settings.buttonColor, color: currentStore.settings.buttonTextColor, borderRadius: btnRadius }}
              >
                <CheckCircle className="w-5 h-5" />
                تأكيد الطلب
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
