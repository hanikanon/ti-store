import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { formatPrice } from '../utils/helpers';
import { Palette, Eye, ShoppingCart, Layout, Type, Square, CircleDot, Minus, Monitor, Smartphone, Tablet } from 'lucide-react';

export default function DesignView() {
  const { dispatch, currentStore, currentProducts } = useStore();
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  if (!currentStore) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const updateSetting = (key: string, value: unknown) => {
    dispatch({
      type: 'UPDATE_STORE',
      payload: {
        ...currentStore,
        settings: { ...currentStore.settings, [key]: value },
      },
    });
  };

  const updateStore = (key: string, value: unknown) => {
    dispatch({
      type: 'UPDATE_STORE',
      payload: { ...currentStore, [key]: value },
    });
  };

  const previewWidth = previewDevice === 'desktop' ? 'w-full' : previewDevice === 'tablet' ? 'max-w-[768px]' : 'max-w-[375px]';

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">التصميم والتخصيص</h1>
        <p className="text-gray-500 mt-1">خصص تصميم متجرك بدون كود</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Settings Panel */}
        <div className="lg:col-span-2 space-y-4">
          {/* Colors */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
              <Palette className="w-5 h-5 text-indigo-500" />
              الألوان
            </h3>
            <div className="space-y-4">
              {[
                { key: 'primaryColor', label: 'اللون الرئيسي' },
                { key: 'secondaryColor', label: 'اللون الثانوي' },
                { key: 'accentColor', label: 'لون التمييز' },
              ].map(color => (
                <div key={color.key} className="flex items-center justify-between">
                  <label className="text-sm text-gray-600">{color.label}</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={(currentStore as unknown as Record<string, unknown>)[color.key] as string}
                      onChange={e => updateStore(color.key, e.target.value)}
                      className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={(currentStore as unknown as Record<string, unknown>)[color.key] as string}
                      onChange={e => updateStore(color.key, e.target.value)}
                      className="w-24 px-2 py-1.5 border border-gray-200 rounded-lg text-xs text-center"
                      dir="ltr"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Button Style */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
              <Square className="w-5 h-5 text-indigo-500" />
              شكل الأزرار
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'rounded', label: 'مدور', icon: <CircleDot className="w-4 h-4" /> },
                { value: 'square', label: 'مربع', icon: <Square className="w-4 h-4" /> },
                { value: 'pill', label: 'كبسولة', icon: <Minus className="w-4 h-4" /> },
              ].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => updateSetting('buttonStyle', opt.value)}
                  className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all ${
                    currentStore.settings.buttonStyle === opt.value
                      ? 'border-indigo-500 bg-indigo-50 text-indigo-600'
                      : 'border-gray-100 text-gray-400 hover:border-gray-200'
                  }`}
                >
                  {opt.icon}
                  <span className="text-xs font-medium">{opt.label}</span>
                </button>
              ))}
            </div>
            <div className="mt-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-600">لون الزر</label>
                <input
                  type="color"
                  value={currentStore.settings.buttonColor}
                  onChange={e => updateSetting('buttonColor', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer"
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-600">لون نص الزر</label>
                <input
                  type="color"
                  value={currentStore.settings.buttonTextColor}
                  onChange={e => updateSetting('buttonTextColor', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Header Style */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
              <Layout className="w-5 h-5 text-indigo-500" />
              تخطيط الهيدر
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'modern', label: 'عصري' },
                { value: 'classic', label: 'كلاسيكي' },
                { value: 'centered', label: 'متوسط' },
              ].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => updateSetting('headerStyle', opt.value)}
                  className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                    currentStore.settings.headerStyle === opt.value
                      ? 'border-indigo-500 bg-indigo-50 text-indigo-600'
                      : 'border-gray-100 text-gray-400 hover:border-gray-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Product Card Style */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
              <Eye className="w-5 h-5 text-indigo-500" />
              بطاقة المنتج
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'minimal', label: 'بسيط' },
                { value: 'detailed', label: 'مفصل' },
                { value: 'modern', label: 'عصري' },
              ].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => updateSetting('productCardStyle', opt.value)}
                  className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                    currentStore.settings.productCardStyle === opt.value
                      ? 'border-indigo-500 bg-indigo-50 text-indigo-600'
                      : 'border-gray-100 text-gray-400 hover:border-gray-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Cart */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
              <ShoppingCart className="w-5 h-5 text-indigo-500" />
              السلة
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-600">إظهار السلة</label>
                <button
                  onClick={() => updateSetting('showCart', !currentStore.settings.showCart)}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    currentStore.settings.showCart ? 'bg-indigo-600' : 'bg-gray-300'
                  } relative`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all ${
                    currentStore.settings.showCart ? 'left-0.5' : 'left-[calc(100%-1.375rem)]'
                  } shadow-sm`}></div>
                </button>
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-600">نمط السلة</label>
                <div className="flex gap-2">
                  {[
                    { value: 'sidebar', label: 'جانبية' },
                    { value: 'page', label: 'صفحة' },
                  ].map(opt => (
                    <button
                      key={opt.value}
                      onClick={() => updateSetting('cartStyle', opt.value)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        currentStore.settings.cartStyle === opt.value
                          ? 'bg-indigo-100 text-indigo-600'
                          : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Announcement Bar */}
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h3 className="font-bold text-gray-900 flex items-center gap-2 mb-4">
              <Type className="w-5 h-5 text-indigo-500" />
              شريط الإعلان
            </h3>
            <div className="space-y-3">
              <input
                type="text"
                value={currentStore.settings.announcementBar || ''}
                onChange={e => updateSetting('announcementBar', e.target.value)}
                placeholder="نص شريط الإعلان (مثال: توصيل مجاني للطلبات فوق 5000 د.ج)"
                className="w-full px-3 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
              />
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-600">لون الخلفية</label>
                <input
                  type="color"
                  value={currentStore.settings.announcementBarColor || currentStore.primaryColor}
                  onChange={e => updateSetting('announcementBarColor', e.target.value)}
                  className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Live Preview */}
        <div className="lg:col-span-3">
          <div className="sticky top-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <Eye className="w-5 h-5 text-indigo-500" />
                معاينة مباشرة
              </h3>
              <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                <button onClick={() => setPreviewDevice('desktop')} className={`p-1.5 rounded-md transition-colors ${previewDevice === 'desktop' ? 'bg-white shadow-sm' : ''}`}>
                  <Monitor className="w-4 h-4 text-gray-600" />
                </button>
                <button onClick={() => setPreviewDevice('tablet')} className={`p-1.5 rounded-md transition-colors ${previewDevice === 'tablet' ? 'bg-white shadow-sm' : ''}`}>
                  <Tablet className="w-4 h-4 text-gray-600" />
                </button>
                <button onClick={() => setPreviewDevice('mobile')} className={`p-1.5 rounded-md transition-colors ${previewDevice === 'mobile' ? 'bg-white shadow-sm' : ''}`}>
                  <Smartphone className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            </div>

            <div className={`bg-gray-100 rounded-2xl p-4 mx-auto transition-all ${previewWidth}`}>
              <div className="bg-white rounded-xl overflow-hidden shadow-sm">
                {/* Announcement Bar */}
                {currentStore.settings.announcementBar && (
                  <div className="py-2 px-4 text-center text-white text-xs font-medium" style={{ background: currentStore.settings.announcementBarColor || currentStore.primaryColor }}>
                    {currentStore.settings.announcementBar}
                  </div>
                )}
                
                {/* Header */}
                <header className="p-4 border-b border-gray-100" style={{ borderColor: `${currentStore.primaryColor}15` }}>
                  <div className={`flex items-center ${currentStore.settings.headerStyle === 'centered' ? 'justify-center' : 'justify-between'}`}>
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold" style={{ background: currentStore.primaryColor }}>
                        {currentStore.name[0]}
                      </div>
                      <span className="font-bold text-sm" style={{ color: currentStore.primaryColor }}>{currentStore.name}</span>
                    </div>
                    {currentStore.settings.headerStyle !== 'centered' && currentStore.settings.showCart && (
                      <ShoppingCart className="w-5 h-5" style={{ color: currentStore.primaryColor }} />
                    )}
                  </div>
                </header>

                {/* Hero */}
                <div className="p-6 text-center" style={{ background: `linear-gradient(135deg, ${currentStore.primaryColor}10, ${currentStore.secondaryColor}10)` }}>
                  <h2 className="text-lg font-bold mb-1" style={{ color: currentStore.primaryColor }}>مرحباً بكم في {currentStore.name}</h2>
                  <p className="text-xs text-gray-500">{currentStore.description || 'أفضل المنتجات بأفضل الأسعار'}</p>
                </div>

                {/* Products */}
                <div className="p-4">
                  <h3 className="font-bold text-sm text-gray-900 mb-3">المنتجات</h3>
                  <div className={`grid gap-3 ${previewDevice === 'mobile' ? 'grid-cols-1' : 'grid-cols-2'}`}>
                    {(currentProducts.length > 0 ? currentProducts.slice(0, 4) : [
                      { name: 'منتج تجريبي 1', price: 2500 },
                      { name: 'منتج تجريبي 2', price: 3500 },
                    ]).map((product, i) => {
                      const btnRadius = currentStore.settings.buttonStyle === 'pill' ? '9999px' : currentStore.settings.buttonStyle === 'square' ? '4px' : '12px';
                      return (
                        <div key={i} className={`border border-gray-100 overflow-hidden ${
                          currentStore.settings.productCardStyle === 'modern' ? 'rounded-2xl' :
                          currentStore.settings.productCardStyle === 'detailed' ? 'rounded-xl' : 'rounded-lg'
                        }`}>
                          <div className="h-24 bg-gradient-to-br from-gray-100 to-gray-50 flex items-center justify-center">
                            <span className="text-2xl">📦</span>
                          </div>
                          <div className="p-3">
                            <p className="font-medium text-xs text-gray-900">{product.name}</p>
                            <p className="font-bold text-sm mt-1" style={{ color: currentStore.primaryColor }}>{formatPrice(product.price)}</p>
                            {currentStore.settings.productCardStyle !== 'minimal' && (
                              <button
                                className="w-full mt-2 py-1.5 text-xs font-medium transition-opacity hover:opacity-80"
                                style={{
                                  background: currentStore.settings.buttonColor,
                                  color: currentStore.settings.buttonTextColor,
                                  borderRadius: btnRadius,
                                }}
                              >
                                أضف للسلة
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Footer */}
                {currentStore.settings.footerEnabled && (
                  <footer className="p-4 text-center border-t border-gray-100">
                    <p className="text-xs text-gray-400">© {currentStore.name} - جميع الحقوق محفوظة</p>
                  </footer>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
