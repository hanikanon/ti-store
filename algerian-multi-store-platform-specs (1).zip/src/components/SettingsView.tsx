import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { Settings, Save, CheckCircle, Trash2, AlertTriangle, Store } from 'lucide-react';

export default function SettingsView() {
  const { dispatch, currentStore } = useStore();
  const [saved, setSaved] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [form, setForm] = useState({
    name: currentStore?.name || '',
    slug: currentStore?.slug || '',
    description: currentStore?.description || '',
    phone: currentStore?.phone || '',
    email: currentStore?.email || '',
    facebook: currentStore?.facebook || '',
    instagram: currentStore?.instagram || '',
    currency: currentStore?.currency || 'د.ج',
  });

  if (!currentStore) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const handleSave = () => {
    dispatch({
      type: 'UPDATE_STORE',
      payload: { ...currentStore, ...form },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleDelete = () => {
    dispatch({ type: 'DELETE_STORE', payload: currentStore.id });
    dispatch({ type: 'SET_VIEW', payload: 'dashboard' });
  };

  return (
    <div className="animate-fade-in max-w-2xl">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">الإعدادات</h1>
        <p className="text-gray-500 mt-1">إعدادات متجر {currentStore.name}</p>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center">
            <Store className="w-6 h-6 text-indigo-500" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">معلومات المتجر</h3>
            <p className="text-sm text-gray-500">البيانات الأساسية للمتجر</p>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">اسم المتجر</label>
            <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">رابط المتجر (Slug)</label>
            <input type="text" value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">وصف المتجر</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
              rows={3} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">العملة</label>
            <input type="text" value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value })}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center">
            <Settings className="w-6 h-6 text-purple-500" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">معلومات التواصل</h3>
            <p className="text-sm text-gray-500">بيانات التواصل والتواصل الاجتماعي</p>
          </div>
        </div>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">الهاتف</label>
              <input type="tel" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">البريد الإلكتروني</label>
              <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">فيسبوك</label>
              <input type="url" value={form.facebook} onChange={e => setForm({ ...form, facebook: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">إنستغرام</label>
              <input type="url" value={form.instagram} onChange={e => setForm({ ...form, instagram: e.target.value })}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none" dir="ltr" />
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={handleSave}
        className="flex items-center gap-2 gradient-bg text-white px-8 py-3 rounded-xl font-medium hover:opacity-90 transition-opacity shadow-lg mb-8"
      >
        {saved ? <CheckCircle className="w-5 h-5" /> : <Save className="w-5 h-5" />}
        {saved ? 'تم الحفظ بنجاح ✓' : 'حفظ الإعدادات'}
      </button>

      {/* Danger Zone */}
      <div className="bg-red-50 border border-red-200 rounded-2xl p-6">
        <h3 className="font-bold text-red-800 flex items-center gap-2 mb-3">
          <AlertTriangle className="w-5 h-5" />
          منطقة الخطر
        </h3>
        <p className="text-sm text-red-600 mb-4">حذف المتجر سيؤدي إلى حذف جميع البيانات المرتبطة به بشكل نهائي</p>
        {!showDelete ? (
          <button
            onClick={() => setShowDelete(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium hover:bg-red-700 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            حذف المتجر
          </button>
        ) : (
          <div className="flex items-center gap-3">
            <button
              onClick={handleDelete}
              className="px-5 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium hover:bg-red-700 transition-colors"
            >
              تأكيد الحذف نهائياً
            </button>
            <button
              onClick={() => setShowDelete(false)}
              className="px-5 py-2.5 bg-gray-200 text-gray-700 rounded-xl text-sm font-medium hover:bg-gray-300 transition-colors"
            >
              إلغاء
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
