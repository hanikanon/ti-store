import { useState } from 'react';
import { useStore } from '../contexts/StoreContext';
import { formatPrice } from '../utils/helpers';
import { Truck, Search, Save, MapPin, Home, Building2 } from 'lucide-react';

export default function DeliveryView() {
  const { state, dispatch, currentDeliveryPrices } = useStore();
  const storeId = state.currentStoreId;
  const [search, setSearch] = useState('');
  const [editingWilaya, setEditingWilaya] = useState<number | null>(null);
  const [homePrice, setHomePrice] = useState('');
  const [officePrice, setOfficePrice] = useState('');

  if (!storeId) return <div className="text-center text-gray-400 py-20">يرجى اختيار متجر أولاً</div>;

  const filtered = currentDeliveryPrices.filter(w =>
    w.nameAr.includes(search) || w.name.toLowerCase().includes(search.toLowerCase()) || w.code.toString().includes(search)
  );

  const startEdit = (code: number) => {
    const w = currentDeliveryPrices.find(x => x.code === code);
    if (w) {
      setEditingWilaya(code);
      setHomePrice(w.homeDeliveryPrice.toString());
      setOfficePrice(w.officeDeliveryPrice.toString());
    }
  };

  const saveEdit = () => {
    if (editingWilaya !== null) {
      dispatch({
        type: 'UPDATE_DELIVERY_PRICE',
        payload: {
          storeId,
          wilayaCode: editingWilaya,
          homePrice: parseFloat(homePrice) || 0,
          officePrice: parseFloat(officePrice) || 0,
        },
      });
      setEditingWilaya(null);
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">التوصيل والولايات</h1>
        <p className="text-gray-500 mt-1">إدارة أسعار التوصيل لجميع الولايات الجزائرية ({currentDeliveryPrices.length} ولاية)</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-2xl p-4 border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
              <MapPin className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-gray-900">{currentDeliveryPrices.length}</p>
              <p className="text-xs text-gray-500">ولاية</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center">
              <Truck className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-gray-900">{currentDeliveryPrices.filter(w => w.isActive).length}</p>
              <p className="text-xs text-gray-500">مفعلة</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center">
              <Home className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-gray-900">{formatPrice(Math.round(currentDeliveryPrices.reduce((s, w) => s + w.homeDeliveryPrice, 0) / currentDeliveryPrices.length))}</p>
              <p className="text-xs text-gray-500">متوسط المنزل</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
              <Building2 className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-gray-900">{formatPrice(Math.round(currentDeliveryPrices.reduce((s, w) => s + w.officeDeliveryPrice, 0) / currentDeliveryPrices.length))}</p>
              <p className="text-xs text-gray-500">متوسط المكتب</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="بحث بالولاية أو الرقم..."
          className="w-full pr-12 pl-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
        />
      </div>

      {/* Wilaya Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(wilaya => (
          <div key={wilaya.code} className="bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 gradient-bg rounded-xl flex items-center justify-center text-white font-bold text-sm">
                  {wilaya.code}
                </div>
                <div>
                  <p className="font-bold text-gray-900">{wilaya.nameAr}</p>
                  <p className="text-xs text-gray-400">{wilaya.name}</p>
                </div>
              </div>
              <span className="text-xs text-gray-400">{wilaya.communes.length} بلدية</span>
            </div>

            {editingWilaya === wilaya.code ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <label className="block text-xs text-gray-500 mb-1">🏠 المنزل</label>
                    <input
                      type="number"
                      value={homePrice}
                      onChange={e => setHomePrice(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                      dir="ltr"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="block text-xs text-gray-500 mb-1">🏢 المكتب</label>
                    <input
                      type="number"
                      value={officePrice}
                      onChange={e => setOfficePrice(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={saveEdit}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
                  >
                    <Save className="w-3.5 h-3.5" />
                    حفظ
                  </button>
                  <button
                    onClick={() => setEditingWilaya(null)}
                    className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg text-sm hover:bg-gray-200 transition-colors"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="bg-amber-50 rounded-xl p-3 text-center">
                    <p className="text-xs text-amber-600 mb-1">🏠 المنزل</p>
                    <p className="font-bold text-amber-800">{formatPrice(wilaya.homeDeliveryPrice)}</p>
                  </div>
                  <div className="bg-blue-50 rounded-xl p-3 text-center">
                    <p className="text-xs text-blue-600 mb-1">🏢 المكتب</p>
                    <p className="font-bold text-blue-800">{formatPrice(wilaya.officeDeliveryPrice)}</p>
                  </div>
                </div>
                <button
                  onClick={() => startEdit(wilaya.code)}
                  className="w-full py-2 text-sm text-indigo-600 hover:bg-indigo-50 rounded-xl transition-colors font-medium"
                >
                  تعديل الأسعار
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
