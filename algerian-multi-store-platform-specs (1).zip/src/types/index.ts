export type OrderStatus = 'مؤكدة' | 'ملغاة' | 'إتصال 1' | 'إتصال 2';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  comparePrice?: number;
  images: string[];
  category: string;
  stock: number;
  variants?: ProductVariant[];
  isActive: boolean;
  createdAt: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  options: string[];
  priceAdjustment: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  countryCode: string;
  wilaya: string;
  commune: string;
  address: string;
  products: OrderProduct[];
  totalAmount: number;
  deliveryFee: number;
  deliveryType: 'home' | 'office';
  status: OrderStatus;
  deviceType: string;
  browser: string;
  createdAt: string;
  notes?: string;
}

export interface OrderProduct {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  variant?: string;
}

export interface WilayaDelivery {
  code: number;
  name: string;
  nameAr: string;
  homeDeliveryPrice: number;
  officeDeliveryPrice: number;
  isActive: boolean;
  communes: Commune[];
}

export interface Commune {
  name: string;
  nameAr: string;
}

export interface Store {
  id: string;
  name: string;
  slug: string;
  description: string;
  logo?: string;
  banner?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  googleAnalyticsId?: string;
  googleSheetId?: string;
  googleAppsScriptUrl?: string;
  currency: string;
  phone?: string;
  email?: string;
  facebook?: string;
  instagram?: string;
  isActive: boolean;
  createdAt: string;
  settings: StoreSettings;
}

export interface StoreSettings {
  showCart: boolean;
  cartStyle: 'sidebar' | 'page';
  productCardStyle: 'minimal' | 'detailed' | 'modern';
  headerStyle: 'centered' | 'classic' | 'modern';
  footerEnabled: boolean;
  announcementBar?: string;
  announcementBarColor?: string;
  buttonStyle: 'rounded' | 'square' | 'pill';
  buttonColor: string;
  buttonTextColor: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  variant?: string;
}

export interface AppState {
  stores: Store[];
  currentStoreId: string | null;
  products: Record<string, Product[]>;
  orders: Record<string, Order[]>;
  deliveryPrices: Record<string, WilayaDelivery[]>;
}
