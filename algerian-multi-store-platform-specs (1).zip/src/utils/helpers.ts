export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

export function generateOrderNumber(): string {
  const prefix = 'DZ';
  const num = Math.floor(Math.random() * 900000) + 100000;
  return `${prefix}-${num}`;
}

export function formatPrice(price: number): string {
  return `${price.toLocaleString('ar-DZ')} د.ج`;
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('ar-DZ', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function getDeviceInfo(): { deviceType: string; browser: string } {
  const ua = navigator.userAgent;
  let deviceType = 'Desktop';
  let browser = 'Unknown';

  if (/Android/i.test(ua)) deviceType = 'Android';
  else if (/iPhone|iPad|iPod/i.test(ua)) {
    deviceType = /iPad/i.test(ua) ? 'Tablet' : 'iPhone';
  } else if (/Tablet/i.test(ua)) deviceType = 'Tablet';

  if (/Chrome/i.test(ua) && !/Edge/i.test(ua)) browser = 'Chrome';
  else if (/Firefox/i.test(ua)) browser = 'Firefox';
  else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) browser = 'Safari';
  else if (/Edge/i.test(ua)) browser = 'Edge';
  else if (/Opera|OPR/i.test(ua)) browser = 'Opera';

  return { deviceType, browser };
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'مؤكدة': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    case 'ملغاة': return 'bg-red-100 text-red-800 border-red-200';
    case 'إتصال 1': return 'bg-amber-100 text-amber-800 border-amber-200';
    case 'إتصال 2': return 'bg-blue-100 text-blue-800 border-blue-200';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
}

export function getStatusIcon(status: string): string {
  switch (status) {
    case 'مؤكدة': return '✓';
    case 'ملغاة': return '✕';
    case 'إتصال 1': return '📞';
    case 'إتصال 2': return '📞';
    default: return '•';
  }
}

export async function sendToGoogleAppsScript(url: string, data: Record<string, unknown>): Promise<unknown> {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
      mode: 'no-cors',
    });
    return response;
  } catch (error) {
    console.error('Error sending to Google Apps Script:', error);
    throw error;
  }
}
