import { useState, useEffect } from 'react';
import { StoreProvider } from './contexts/StoreContext';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';

function App() {
  const [view, setView] = useState<'landing' | 'dashboard'>(() => {
    return localStorage.getItem('dz-store-view') === 'dashboard' ? 'dashboard' : 'landing';
  });

  useEffect(() => {
    localStorage.setItem('dz-store-view', view);
  }, [view]);

  if (view === 'landing') {
    return <LandingPage onEnterDashboard={() => setView('dashboard')} />;
  }

  return (
    <StoreProvider>
      <Dashboard onLogout={() => setView('landing')} />
    </StoreProvider>
  );
}

export default App;
