import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { Store, Product, Order, WilayaDelivery, OrderStatus } from '../types';
import { algerianWilayas } from '../data/wilayas';

interface State {
  stores: Store[];
  currentStoreId: string | null;
  products: Record<string, Product[]>;
  orders: Record<string, Order[]>;
  deliveryPrices: Record<string, WilayaDelivery[]>;
  sidebarOpen: boolean;
  currentView: string;
}

type Action =
  | { type: 'SET_STORES'; payload: Store[] }
  | { type: 'ADD_STORE'; payload: Store }
  | { type: 'UPDATE_STORE'; payload: Store }
  | { type: 'DELETE_STORE'; payload: string }
  | { type: 'SET_CURRENT_STORE'; payload: string | null }
  | { type: 'ADD_PRODUCT'; payload: { storeId: string; product: Product } }
  | { type: 'UPDATE_PRODUCT'; payload: { storeId: string; product: Product } }
  | { type: 'DELETE_PRODUCT'; payload: { storeId: string; productId: string } }
  | { type: 'ADD_ORDER'; payload: { storeId: string; order: Order } }
  | { type: 'UPDATE_ORDER_STATUS'; payload: { storeId: string; orderId: string; status: OrderStatus } }
  | { type: 'SET_DELIVERY_PRICES'; payload: { storeId: string; prices: WilayaDelivery[] } }
  | { type: 'UPDATE_DELIVERY_PRICE'; payload: { storeId: string; wilayaCode: number; homePrice: number; officePrice: number } }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'SET_VIEW'; payload: string }
  | { type: 'LOAD_STATE'; payload: Partial<State> };

const initialState: State = {
  stores: [],
  currentStoreId: null,
  products: {},
  orders: {},
  deliveryPrices: {},
  sidebarOpen: true,
  currentView: 'dashboard',
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'LOAD_STATE':
      return { ...state, ...action.payload };
    case 'SET_STORES':
      return { ...state, stores: action.payload };
    case 'ADD_STORE': {
      const newStores = [...state.stores, action.payload];
      const storeId = action.payload.id;
      return {
        ...state,
        stores: newStores,
        products: { ...state.products, [storeId]: [] },
        orders: { ...state.orders, [storeId]: [] },
        deliveryPrices: { ...state.deliveryPrices, [storeId]: JSON.parse(JSON.stringify(algerianWilayas)) },
        currentStoreId: storeId,
      };
    }
    case 'UPDATE_STORE':
      return {
        ...state,
        stores: state.stores.map(s => s.id === action.payload.id ? action.payload : s),
      };
    case 'DELETE_STORE': {
      const newProducts = { ...state.products };
      const newOrders = { ...state.orders };
      const newDelivery = { ...state.deliveryPrices };
      delete newProducts[action.payload];
      delete newOrders[action.payload];
      delete newDelivery[action.payload];
      return {
        ...state,
        stores: state.stores.filter(s => s.id !== action.payload),
        products: newProducts,
        orders: newOrders,
        deliveryPrices: newDelivery,
        currentStoreId: state.currentStoreId === action.payload ? null : state.currentStoreId,
      };
    }
    case 'SET_CURRENT_STORE':
      return { ...state, currentStoreId: action.payload };
    case 'ADD_PRODUCT':
      return {
        ...state,
        products: {
          ...state.products,
          [action.payload.storeId]: [
            ...(state.products[action.payload.storeId] || []),
            action.payload.product,
          ],
        },
      };
    case 'UPDATE_PRODUCT':
      return {
        ...state,
        products: {
          ...state.products,
          [action.payload.storeId]: (state.products[action.payload.storeId] || []).map(
            p => p.id === action.payload.product.id ? action.payload.product : p
          ),
        },
      };
    case 'DELETE_PRODUCT':
      return {
        ...state,
        products: {
          ...state.products,
          [action.payload.storeId]: (state.products[action.payload.storeId] || []).filter(
            p => p.id !== action.payload.productId
          ),
        },
      };
    case 'ADD_ORDER':
      return {
        ...state,
        orders: {
          ...state.orders,
          [action.payload.storeId]: [
            action.payload.order,
            ...(state.orders[action.payload.storeId] || []),
          ],
        },
      };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: {
          ...state.orders,
          [action.payload.storeId]: (state.orders[action.payload.storeId] || []).map(
            o => o.id === action.payload.orderId ? { ...o, status: action.payload.status } : o
          ),
        },
      };
    case 'SET_DELIVERY_PRICES':
      return {
        ...state,
        deliveryPrices: {
          ...state.deliveryPrices,
          [action.payload.storeId]: action.payload.prices,
        },
      };
    case 'UPDATE_DELIVERY_PRICE':
      return {
        ...state,
        deliveryPrices: {
          ...state.deliveryPrices,
          [action.payload.storeId]: (state.deliveryPrices[action.payload.storeId] || []).map(
            w => w.code === action.payload.wilayaCode
              ? { ...w, homeDeliveryPrice: action.payload.homePrice, officeDeliveryPrice: action.payload.officePrice }
              : w
          ),
        },
      };
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarOpen: !state.sidebarOpen };
    case 'SET_VIEW':
      return { ...state, currentView: action.payload };
    default:
      return state;
  }
}

interface StoreContextType {
  state: State;
  dispatch: React.Dispatch<Action>;
  currentStore: Store | null;
  currentProducts: Product[];
  currentOrders: Order[];
  currentDeliveryPrices: WilayaDelivery[];
}

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('dz-store-state');
      if (saved) {
        const parsed = JSON.parse(saved);
        dispatch({ type: 'LOAD_STATE', payload: parsed });
      }
    } catch (e) {
      console.error('Failed to load state', e);
    }
  }, []);

  useEffect(() => {
    const toSave = {
      stores: state.stores,
      currentStoreId: state.currentStoreId,
      products: state.products,
      orders: state.orders,
      deliveryPrices: state.deliveryPrices,
    };
    localStorage.setItem('dz-store-state', JSON.stringify(toSave));
  }, [state.stores, state.currentStoreId, state.products, state.orders, state.deliveryPrices]);

  const currentStore = state.stores.find(s => s.id === state.currentStoreId) || null;
  const currentProducts = state.currentStoreId ? (state.products[state.currentStoreId] || []) : [];
  const currentOrders = state.currentStoreId ? (state.orders[state.currentStoreId] || []) : [];
  const currentDeliveryPrices = state.currentStoreId ? (state.deliveryPrices[state.currentStoreId] || []) : [];

  return (
    <StoreContext.Provider value={{ state, dispatch, currentStore, currentProducts, currentOrders, currentDeliveryPrices }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}
