// متجر الأناقة Store App
const PRODUCTS = [{"id":"1e73a997-ea86-43db-8d9a-98cbf3c0026e","name":"منتج مميز 1","price":99,"originalPrice":149,"description":"منتج عالي الجودة بأفضل الأسعار","image":"https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400","category":"عام","inStock":true,"badge":"جديد"},{"id":"4e4eac44-38ed-415b-a051-cd92b699cc61","name":"منتج مميز 2","price":149,"originalPrice":199,"description":"تصميم أنيق وجودة عالية","image":"https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=400","category":"عام","inStock":true,"badge":"الأكثر مبيعاً"},{"id":"806f149d-4d91-493f-8cf1-5c5917b472ce","name":"منتج مميز 3","price":199,"description":"المنتج الأمثل لاحتياجاتك","image":"https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=400","category":"عام","inStock":true},{"id":"902b8144-65f4-4549-815d-325e202e32fa","name":"منتج مميز 4","price":79,"originalPrice":120,"description":"جودة ممتازة بسعر منافس","image":"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400","category":"عام","inStock":false,"badge":"تخفيض"}];
const CURRENCY = 'SAR';
let cart = [];

// Mobile Menu
function toggleMenu() {
  const menu = document.getElementById('mobileMenu');
  const overlay = document.getElementById('overlay');
  menu.classList.toggle('open');
  overlay.classList.toggle('show');
}

// Cart
function toggleCart() {
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartOverlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('show');
}

function addToCart(id, name, price) {
  const product = PRODUCTS.find(p => p.id === id);
  if (!product || !product.inStock) return;
  const existing = cart.find(i => i.id === id);
  if (existing) {
    existing.qty++;
  } else {
    cart.push({ id, name, price, qty: 1, image: product.image });
  }
  updateCart();
  showToast('✅ تم إضافة ' + name + ' إلى السلة!');
  if (typeof trackAddToCart !== 'undefined') trackAddToCart(name, price);
}

function removeFromCart(id) {
  cart = cart.filter(i => i.id !== id);
  updateCart();
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (item) {
    item.qty += delta;
    if (item.qty <= 0) removeFromCart(id);
    else updateCart();
  }
}

function updateCart() {
  const count = cart.reduce((a, i) => a + i.qty, 0);
  const total = cart.reduce((a, i) => a + i.price * i.qty, 0);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartTotal').textContent = total.toFixed(2) + ' ' + CURRENCY;
  const itemsEl = document.getElementById('cartItems');
  if (cart.length === 0) {
    itemsEl.innerHTML = '<div class="cart-empty">🛍️ سلتك فارغة<br/><small>أضف منتجات للبدء</small></div>';
    return;
  }
  itemsEl.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" />
      <div class="cart-item-info">
        <h4>${item.name}</h4>
        <div class="cart-item-price">${(item.price * item.qty).toFixed(2)} ${CURRENCY}</div>
        <div class="cart-item-qty">
          <button class="qty-btn" onclick="changeQty('${item.id}', -1)">−</button>
          <span>${item.qty}</span>
          <button class="qty-btn" onclick="changeQty('${item.id}', 1)">+</button>
          <button class="qty-btn" onclick="removeFromCart('${item.id}')" style="background:#FEE2E2;color:#EF4444;">🗑️</button>
        </div>
      </div>
    </div>
  `).join('');
}

function checkout() {
  if (cart.length === 0) { showToast('❌ السلة فارغة!'); return; }
  showToast('🎉 شكراً لطلبك! سنتواصل معك قريباً.');
  cart = [];
  updateCart();
  toggleCart();
}

// Filter Products
function filterProducts(type, btn) {
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const grid = document.getElementById('productsGrid');
  let filtered = PRODUCTS;
  if (type === 'inStock') filtered = PRODUCTS.filter(p => p.inStock);
  if (type === 'sale') filtered = PRODUCTS.filter(p => p.originalPrice);
  grid.innerHTML = filtered.map(p => `
    <div class="product-card">
      ${p.badge ? `<div class="product-badge">${p.badge}</div>` : ''}
      ${!p.inStock ? '<div class="product-badge out-stock">نفد المخزون</div>' : ''}
      <div class="product-img-wrap"><img src="${p.image}" alt="${p.name}" loading="lazy" /></div>
      <div class="product-info">
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="product-price">
          <span class="price-current">${p.price} ${CURRENCY}</span>
          ${p.originalPrice ? `<span class="price-original">${p.originalPrice} ${CURRENCY}</span>` : ''}
        </div>
        <button class="btn-cart" ${!p.inStock ? 'disabled' : ''} onclick="addToCart('${p.id}', '${p.name}', ${p.price})">
          ${p.inStock ? '🛒 أضف إلى السلة' : '❌ غير متوفر'}
        </button>
      </div>
    </div>
  `).join('');
}

// Toast
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}

// Newsletter
function subscribeNewsletter(e) {
  e.preventDefault();
  showToast('🎉 شكراً! تم تسجيلك بنجاح في النشرة البريدية.');
  e.target.reset();
  if (typeof gtag !== 'undefined') gtag('event', 'newsletter_subscribe', { event_category: 'engagement' });
}

// Contact
function submitContact(e) {
  e.preventDefault();
  showToast('✅ تم إرسال رسالتك! سنرد عليك قريباً.');
  e.target.reset();
  if (typeof gtag !== 'undefined') gtag('event', 'contact_submit', { event_category: 'engagement' });
}

// Sticky Header
window.addEventListener('scroll', () => {
  const header = document.getElementById('header');
  header.style.boxShadow = window.scrollY > 50 ? '0 4px 30px rgba(0,0,0,0.4)' : '0 2px 20px rgba(0,0,0,0.3)';
});

// Animate on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) { e.target.style.opacity = '1'; e.target.style.transform = 'translateY(0)'; }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.product-card, .feature-card, .testimonial-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
  observer.observe(el);
});

console.log('متجر الأناقة Store loaded successfully! 🚀');
