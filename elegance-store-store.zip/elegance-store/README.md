# متجر الأناقة - متجر إلكتروني

## 📋 نظرة عامة
متجر الموضة والأزياء العصرية

## 🚀 النشر على GitHub Pages

### الخطوة 1: إنشاء مستودع
```bash
git init
git add .
git commit -m "Initial store setup: متجر الأناقة"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/elegance-store.git
git push -u origin main
```

### الخطوة 2: تفعيل GitHub Pages
1. افتح إعدادات المستودع (Settings)
2. انتقل إلى Pages
3. اختر المصدر: main branch
4. احفظ الإعدادات

### الخطوة 3: رابط المتجر
`https://YOUR_USERNAME.github.io/elegance-store/`

## 📊 Google Analytics
لم يتم إعداد Google Analytics بعد.
أضف معرف GA في إعدادات المتجر ثم أعد التصدير.

## 📁 هيكل الملفات
```
elegance-store/
├── index.html    # الصفحة الرئيسية
├── style.css     # التصميم والأنماط
├── app.js        # الوظائف والتفاعل
└── README.md     # هذا الملف
```

## ✏️ التخصيص
- **الألوان**: يمكن تغييرها في style.css في قسم :root
- **المنتجات**: تحديثها في app.js في متغير PRODUCTS
- **الشعار**: تعديل emoji الشعار في index.html

## 📞 معلومات الاتصال
- 📞 +966 50 000 0000
- 📧 info@elegance.com
- 📍 الرياض، المملكة العربية السعودية

---
*تم إنشاء هذا المتجر بواسطة StoreForge Platform*
